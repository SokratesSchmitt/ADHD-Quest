/**
 * ============================================================================
 * ADHD-QUEST CORE ENGINE v0.26 (1:1 Google Sheet Datenstruktur + Live-Sync)
 * ============================================================================
 * Basiert exakt auf deiner Google-Tabelle "ADHD Quest":
 * - Charakterbogen: MB (B3) = 94, HP (B4) = 54, Level (B6) = 25, XP (B8) = 59005, Gold (B10) = 9424, AP (D10) = 7
 * - MB Aktivitaeten (Spalten A: Aktivitaet, B: MB-Heilung, C: XP, D-G: Spaß/Kompetenz/Soziales/Selbstwert, H: Aktionspunkte, I: Status, M: Raum, N: Repräsentiert durch)
 * - Aufgaben (Spalten A: Aufgaben im Haushalt, B: MB-Heilung, C: XP, H: Gold, I: Aktionspunkte, J: Status, M: Raum, N: Repräsentiert durch)
 * - Shop (Spalten A: Aktivitaet, B: Preis, C: Status, E: Aktionspunktkosten)
 * - Frontend_Raum_Objekte (Spalten A: Raum, B: Beschreibung, C: posX, D: posY, E: Verknüpfung, F: Tabelle, G: iconUrl, H: soundUrl, I: id, J: iconName, K: soundName)
 * - Raum_adressen (Badezimmer, Dashboard, Map, Küche, Wohnzimmer, Startbildschirm, Startlogo + Flur & Schlafzimmer)
 * - Questlog (A: Datum, B: Uhrzeit, C: Aktivität, D: Typ, E: XP, F: MB, G: Gold, H: Aktionspunkte)
 * - Achievements (Beständiger Geist, Wochenheld, Monatsveteran)
 */
const Engine = (function () {
  const APP_VERSION = "0.71";
  const STORAGE_KEY = "ADHD_QUEST_SHEET_STATE_V0_38";
  const SPLASH_DATE_KEY = "adhdQuest_lastSplashDate";

  // Deine Live Google Apps Script Web-App URL aus dem Tabellenblatt "Dokumentation"
  const GAS_API_URL = "https://script.google.com/macros/s/AKfycbz3w5odPMFVRZ9hhMdhvMIwg6A0N6Fi2N6cKxu6aOTBKnilqYjptIbuAWbA5qYMu1-E5Q/exec";

  // 1. Tabellenblatt "Raum_adressen" + neue lokale Grafiken (Intro, Map, Flur)
  const ASSETS = {
    backgrounds: {
      "Startbildschirm": "aq_schriftzugtitle.png",
      "Startlogo": "https://raw.githubusercontent.com/SokratesSchmitt/ADHD-Quest/main/backgrounds/bg_startlogo.png",
      "Map": "assets/bg_map_orig.png",
      "Flur": "assets/bg_flur.jpg",
      "Dashboard": "assets/bg_dashboard.jpg",
      "Arbeitszimmer": "assets/bg_dashboard.jpg",
      "Wohnzimmer": "assets/bg_livingroom_me.jpg",
      "Küche": "assets/bg_kitchen.jpg",
      "Badezimmer": "assets/bg_bathroom.jpg",
      "Schlafzimmer": "assets/bg_bedroom.jpg",
      "Kinderzimmer": "assets/bg_kinderzimmer.jpg"
    },
    dirtyBackgrounds: {
      "Flur": [
        "assets/bg_flur.jpg",
        "assets/bg_flur_dirty_s1.jpg",
        "assets/bg_flur_dirty_s2.jpg",
        "assets/bg_flur_dirty_s3.jpg"
      ],
      "Wohnzimmer": [
        "assets/bg_livingroom_me.jpg",
        "assets/bg_wohnzimmer_dirty_s1.jpg",
        "assets/bg_wohnzimmer_dirty_s2.jpg",
        "assets/bg_wohnzimmer_dirty_s3.jpg"
      ],
      "Küche": [
        "assets/bg_kitchen.jpg",
        "assets/bg_kueche_dirty_s1.jpg",
        "assets/bg_kueche_dirty_s2.jpg",
        "assets/bg_kueche_dirty_s3.jpg"
      ],
      "Badezimmer": [
        "assets/bg_bathroom.jpg",
        "assets/bg_badezimmer_dirty_s1.jpg",
        "assets/bg_badezimmer_dirty_s2.jpg",
        "assets/bg_badezimmer_dirty_s3.jpg"
      ],
      "Schlafzimmer": [
        "assets/bg_bedroom.jpg",
        "assets/bg_schlafzimmer_dirty_s1.jpg",
        "assets/bg_schlafzimmer_dirty_s2.jpg",
        "assets/bg_schlafzimmer_dirty_s3.jpg"
      ]
    },
    luggageSprite: "assets/sprite_dev_luggage.png",
    cleaningToolSprites: {
      1: "assets/cleaning_sprites/sprite_clean_besen_s1.png",
      2: "assets/cleaning_sprites/sprite_clean_kehrset_s2.png",
      3: "assets/cleaning_sprites/sprite_clean_staubsauger_s3.png"
    },
    // Position des Besens / Staubsaugers direkt neben der jeweiligen Zimmertür (Nur für die 5 Räume mit Müll-Logik; Dashboard & Kinderzimmer sind ausgenommen!)
    doorCleaningCoords: {
      "Flur":         { leftPct: 54.0, topPct: 52.0, widthPct: 16.5, heightPct: 18.5, zIndex: 20, taskName: "Zimmer oder Wohnung aufräumen (30 min)", zielTabelle: "MB Aktivitaeten", verknuepfung: "A18", baseXp: 50,  baseGold: 25, baseMb: 1, baseAp: 1 },
      "Wohnzimmer":   { leftPct: 36.5, topPct: 46.5, widthPct: 16.5, heightPct: 18.5, zIndex: 20, taskName: "Samstagsputz (Wohnzimmer)",             zielTabelle: "Aufgaben",        verknuepfung: "A8",  baseXp: 125, baseGold: 50, baseMb: 0, baseAp: 2 },
      "Küche":        { leftPct: 73.5, topPct: 50.0, widthPct: 16.5, heightPct: 18.5, zIndex: 20, taskName: "Samstagsputz (Küche)",                  zielTabelle: "Aufgaben",        verknuepfung: "A7",  baseXp: 100, baseGold: 50, baseMb: 0, baseAp: 2 },
      "Schlafzimmer": { leftPct: 60.5, topPct: 48.0, widthPct: 16.5, heightPct: 18.5, zIndex: 20, taskName: "Samstagsputz (Schlafzimmer)",           zielTabelle: "Aufgaben",        verknuepfung: "A9",  baseXp: 150, baseGold: 50, baseMb: 0, baseAp: 2 },
      "Badezimmer":   { leftPct: 37.5, topPct: 46.5, widthPct: 16.5, heightPct: 18.5, zIndex: 20, taskName: "Samstagsputz (Bad)",                    zielTabelle: "Aufgaben",        verknuepfung: "A10", baseXp: 125, baseGold: 50, baseMb: 0, baseAp: 2 }
    },
    uiFrames: [
      {
        id: "frame_1_wood_gold",
        nr: 1,
        label: "Rahmen 1: Ultra-Slim Holz & Gold-Intarsie",
        desc: "Nur 5px schmale Edelholz-Kante mit goldener Intarsienlinie (99% Vollbild)",
        overlayUrl: "assets/ui_frames/frame_1_wood_gold.png",
        showRoomBadge: false
      },
      {
        id: "frame_2_corner_brackets",
        nr: 2,
        label: "Rahmen 2: Offene Eck-Beschläge (Corner-L)",
        desc: "Seitenkanten 100% frei – nur die 4 Ecken sind mit Holz-/Messing-Winkeln gefasst",
        overlayUrl: "assets/ui_frames/frame_2_corner_brackets.png",
        showRoomBadge: false
      },
      {
        id: "frame_3_comic_ink",
        nr: 3,
        label: "Rahmen 3: Comic-Ink & Inner-Glow Aura",
        desc: "0px Randverlust – Graphic-Novel-Tuschekontur mit bernsteinfarbenem Inner-Glow & Raum-Plakette",
        overlayUrl: "assets/ui_frames/frame_3_comic_ink.png",
        showRoomBadge: true
      },
      {
        id: "none",
        nr: 0,
        label: "Kein Rahmen (Randloses Rohbild)",
        desc: "Komplett ohne UI-Umrahmung",
        overlayUrl: "",
        showRoomBadge: false
      }
    ],
    // Spezifische Lampen-, Kerzen- & Lichtquellen-Koordinaten pro Raum (für Golden Hour & Nachtlicht ab 21 Uhr)
    roomLampGlows: {
      "Flur": [
        { cx: 59.0, cy: 19.0, rx: 18.0, ry: 12.0, color: "rgba(255, 196, 85, 0.52)" }, // Obere Hängelampen an der Holzempore
        { cx: 41.8, cy: 42.8, rx: 22.0, ry: 16.0, color: "rgba(255, 184, 68, 0.58)" }  // Untere Glühbirne über der Kommode
      ],
      "Dashboard": [
        { cx: 84.5, cy: 14.0, rx: 20.0, ry: 13.0, color: "rgba(255, 198, 92, 0.52)" }, // Zwei Hänge-Glühbirnen oben rechts
        { cx: 26.8, cy: 55.5, rx: 25.0, ry: 18.0, color: "rgba(255, 208, 102, 0.62)" } // Schreibtischlampe (Vibe Coding Fokus-Licht)
      ],
      "Wohnzimmer": [
        { cx: 21.5, cy: 19.0, rx: 25.0, ry: 16.0, color: "rgba(255, 196, 82, 0.58)" }, // 3-armiger Messing-Kronleuchter links oben
        { cx: 81.5, cy: 16.5, rx: 24.0, ry: 14.0, color: "rgba(255, 190, 76, 0.52)" }, // Lichterkette & Hängelampen rechts oben
        { cx: 68.5, cy: 48.0, rx: 20.0, ry: 14.0, color: "rgba(255, 168, 64, 0.35)" }  // Warmes Studio-Licht in der Musikecke
      ],
      "Küche": [
        { cx: 76.0, cy: 16.0, rx: 24.0, ry: 15.0, color: "rgba(255, 198, 88, 0.56)" }, // Zwei Hänge-Glühbirnen oben rechts
        { cx: 24.0, cy: 49.0, rx: 24.0, ry: 15.0, color: "rgba(255, 184, 78, 0.38)" }  // Warmes Licht über Herd & Arbeitsfläche
      ],
      "Schlafzimmer": [
        { cx: 18.0, cy: 16.5, rx: 24.0, ry: 12.0, color: "rgba(255, 192, 82, 0.54)" }, // Lichterkette an der Ziegelwand links oben
        { cx: 76.0, cy: 16.5, rx: 22.0, ry: 13.0, color: "rgba(255, 196, 88, 0.52)" }, // Hänge-Glühbirnen rechts oben
        { cx: 27.5, cy: 55.5, rx: 16.0, ry: 12.0, color: "rgba(255, 162, 48, 0.68)", flicker: true }, // Brennende Kerzen hinten am Bett
        { cx: 6.5,  cy: 66.5, rx: 16.0, ry: 12.0, color: "rgba(255, 162, 48, 0.68)", flicker: true }  // Brennende Kerzen vorne am Nachttisch
      ],
      "Badezimmer": [
        { cx: 76.0, cy: 15.5, rx: 24.0, ry: 14.0, color: "rgba(255, 202, 96, 0.55)" }, // Zwei Hänge-Glühbirnen oben rechts
        { cx: 88.0, cy: 46.0, rx: 18.0, ry: 16.0, color: "rgba(255, 214, 128, 0.42)" } // Warmes Spiegellicht am Waschtisch
      ],
      "Kinderzimmer": [
        { cx: 92.0, cy: 36.0, rx: 22.0, ry: 26.0, color: "rgba(255, 204, 112, 0.38)" }, // Sanftes Fenster-/Abendlicht rechts
        { cx: 65.0, cy: 48.0, rx: 28.0, ry: 20.0, color: "rgba(255, 192, 96, 0.46)" }   // Gemütliches Gute-Nacht-Leselicht am Bodenbett
      ]
    }
  };


  // 1b. Offizielle Designreferenz für Profilbild & 10 Spielerfigur-States (Schiebermütze, Brille, Vollbart & blau-braunes Karohemd)
  const PLAYER_DESIGN_REF = {
    profileRef: "assets/avatar/avatar_profile_ref.png",
    states: [
      { id: "state_01_neutral",  nr: 1,  label: "Neutral / Bereit",          mbRange: "75–100% MB (Standard)",  fullSprite: "assets/avatar/player_state_01_neutral.png",  portrait: "assets/avatar/portrait_state_01_neutral.png" },
      { id: "state_02_thumbsup", nr: 2,  label: "Daumen hoch / Motiviert",   mbRange: "85–100% MB (Gut drauf)", fullSprite: "assets/avatar/player_state_02_thumbsup.png", portrait: "assets/avatar/portrait_state_02_thumbsup.png" },
      { id: "state_03_waving",   nr: 3,  label: "Winkend / Begrüßung",       mbRange: "Raumwechsel / Hallo",    fullSprite: "assets/avatar/player_state_03_waving.png",   portrait: "assets/avatar/portrait_state_03_waving.png" },
      { id: "state_04_thinking", nr: 4,  label: "Grübelnd / Planend (?)",    mbRange: "55–74% MB (Planung)",    fullSprite: "assets/avatar/player_state_04_thinking.png", portrait: "assets/avatar/portrait_state_04_thinking.png" },
      { id: "state_05_yawning",  nr: 5,  label: "Gähnend / Müde",            mbRange: "20–39% MB (Müde)",       fullSprite: "assets/avatar/player_state_05_yawning.png",  portrait: "assets/avatar/portrait_state_05_yawning.png" },
      { id: "state_06_laughing", nr: 6,  label: "Herzlich lachend",          mbRange: "Spaß- & Witz-Aktivität", fullSprite: "assets/avatar/player_state_06_laughing.png", portrait: "assets/avatar/portrait_state_06_laughing.png" },
      { id: "state_07_action",   nr: 7,  label: "Aktiv / Anpackend",         mbRange: "Haushalts-Quest aktiv",  fullSprite: "assets/avatar/player_state_07_action.png",   portrait: "assets/avatar/portrait_state_07_action.png" },
      { id: "state_08_sipping",  nr: 8,  label: "Kaffee-Pause (aktiv)",      mbRange: "60–79% MB (Fokus)",      fullSprite: "assets/avatar/player_state_08_sipping.png",  portrait: "assets/avatar/portrait_state_08_sipping.png" },
      { id: "state_09_cozy_mug", nr: 9,  label: "Genießend mit Tasse",       mbRange: "40–54% MB (Regeneration)",fullSprite: "assets/avatar/player_state_09_cozy_mug.png", portrait: "assets/avatar/portrait_state_09_cozy_mug.png" },
      { id: "state_10_cheering", nr: 10, label: "Jubelnd / Quest erledigt!", mbRange: "Loot-Jubel & Level-Up",  fullSprite: "assets/avatar/player_state_10_cheering.png", portrait: "assets/avatar/portrait_state_10_cheering.png" },
      { id: "state_11_armchair", nr: 11, label: "Erschöpft im Sessel",       mbRange: "0–19% MB (Ruhe nötig)",  fullSprite: "assets/avatar/player_state_11_armchair.png", portrait: "assets/avatar/portrait_state_11_armchair.png" }
    ]
  };

  // 2. Interaktive Wohnungs-Map (Neuer 7-Raum-Grundriss v0.37 mit entlang der Innenwände freigestellten Raum-Sprites)
  const ROOMS = [
    {
      id: "Kinderzimmer",
      icon: "🦄",
      desc: "Gelato-Girl-Poster, Korg-Minipiano, Einhorn, Holzeisenbahn & Basteltisch",
      bgUrl: ASSETS.backgrounds["Kinderzimmer"],
      mapSprite: "assets/map_sprites/sprite_map_kinderzimmer.png",
      leftPct: 4.22, topPct: 6.25, widthPct: 28.63, heightPct: 53.12, zIndex: 5
    },
    {
      id: "Flur",
      icon: "🚪",
      desc: "Bücherregal, Eulen-Uhr, freies Holzbrett & Wohnungstür",
      bgUrl: ASSETS.backgrounds["Flur"],
      mapSprite: "assets/map_sprites/sprite_map_flur.png",
      leftPct: 4.22, topPct: 59.90, widthPct: 36.48, heightPct: 33.59, zIndex: 5,
      clipPath: "polygon(0% 3.1%, 80.9% 3.1%, 80.9% 0%, 100% 0%, 100% 100%, 0% 100%)"
    },
    {
      id: "Wohnzimmer",
      icon: "🛋️",
      desc: "Schöne Musik, Instrumente, Filme & Erholung",
      bgUrl: ASSETS.backgrounds["Wohnzimmer"],
      mapSprite: "assets/map_sprites/sprite_map_wohnzimmer.png",
      leftPct: 33.79, topPct: 6.25, widthPct: 32.34, heightPct: 53.65, zIndex: 5
    },
    {
      id: "Dashboard",
      icon: "🏠",
      desc: "Arbeitszimmer / Haupt-Dashboard, Tagesplaner, Shop & Questlog",
      bgUrl: ASSETS.backgrounds["Dashboard"],
      mapSprite: "assets/map_sprites/sprite_map_arbeitszimmer.png",
      leftPct: 41.28, topPct: 61.46, widthPct: 24.85, heightPct: 32.03, zIndex: 6
    },
    {
      id: "Schlafzimmer",
      icon: "🛏️",
      desc: "Erholung, Massageöl, Teleskop & Samstagsputz",
      bgUrl: ASSETS.backgrounds["Schlafzimmer"],
      mapSprite: "assets/map_sprites/sprite_map_schlafzimmer.png",
      leftPct: 67.15, topPct: 6.25, widthPct: 28.63, heightPct: 34.11, zIndex: 5
    },
    {
      id: "Badezimmer",
      icon: "🚿",
      desc: "Schwimmen, Kalt duschen & Bad-Routine",
      bgUrl: ASSETS.backgrounds["Badezimmer"],
      mapSprite: "assets/map_sprites/sprite_map_badezimmer.png",
      leftPct: 75.29, topPct: 42.19, widthPct: 20.49, heightPct: 21.88, zIndex: 6
    },
    {
      id: "Küche",
      icon: "🍳",
      desc: "Geschirrspüler, Tisch abwischen & Mittagessen",
      bgUrl: ASSETS.backgrounds["Küche"],
      mapSprite: "assets/map_sprites/sprite_map_kueche.png",
      leftPct: 67.01, topPct: 42.19, widthPct: 28.78, heightPct: 51.30, zIndex: 5,
      clipPath: "polygon(0% 0%, 19.2% 0%, 19.2% 45.7%, 100% 45.7%, 100% 100%, 0% 100%)"
    }
  ];

  // Hilfsfunktion: Wandelt FlutterFlow/Sheet-Koordinaten (-1.0 bis +1.0) in CSS-Prozent (0% bis 100%) um
  function alignToPct(val, fallbackPct) {
    if (typeof val !== "number" || isNaN(val)) return fallbackPct;
    if (val >= -1.0 && val <= 1.0) {
      return Math.round(((val + 1) / 2) * 1000) / 10;
    }
    return val;
  }

  // 3. Tabellenblätter "Aufgaben", "MB Aktivitaeten" & "Frontend_Raum_Objekte"
  // Alle Einträge nutzen exakt die Namen (`name`) und Ziel-Tabellen (`zielTabelle`: "Aufgaben" oder "MB Aktivitaeten") deiner Google-Tabelle!
  const ROOM_OBJECTS = {
    "Flur": [
      {
        id: "FLU_001_01",
        raum: "Flur",
        name: "Tisch abwischen",
        anzeigeName: "Holzbrett der vorderen Kommode frei halten (Tisch abwischen / 30 min aufräumen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A17",
        icon: "✨",
        iconUrl: "assets/icons/icon_flu_holzbrett.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_holzbrett.png",
        leftPct: 0.00, topPct: 61.00, widthPct: 29.50, heightPct: 9.80, zIndex: 12,
        mb: 0, xp: 5, gold: 5, ap: 1,
        repr: "Freies braunes Holzbrett auf der Flur-Kommode"
      },
      {
        id: "FLU_002_01",
        raum: "Flur",
        name: "Witze anhören oder einfach nur so lachen",
        anzeigeName: "Brettspiel-Stapel & Witzebuch im Wandregal (Witze anhören / Neues probieren)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A6",
        icon: "🎲",
        iconUrl: "assets/icons/icon_flu_buecherregal.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_buecherregal.png",
        leftPct: 4.20, topPct: 34.50, widthPct: 13.00, heightPct: 6.41, zIndex: 16,
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Brettspiel-Stapel & Witzebuch im linken Wandregal"
      },
      {
        id: "FLU_003_01",
        raum: "Flur",
        name: "10000 Schritte um 5 Uhr gehen",
        anzeigeName: "Oranger Eulen-Wecker im Wandregal (10.000 Schritte um 5 Uhr / Atemübung)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A17",
        icon: "🦉",
        iconUrl: "assets/icons/icon_flu_eule.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_eule.png",
        leftPct: 5.50, topPct: 47.20, widthPct: 9.50, heightPct: 6.34, zIndex: 17,
        mb: 5, xp: 100, gold: 0, ap: 3,
        repr: "Oranger Eulen-Wecker im Flurregal"
      },
      {
        id: "FLU_004_01",
        raum: "Flur",
        name: "Wäsche zusammenlegen",
        anzeigeName: "Grün-weiße Kommoden-Schubladen hinten (Wäsche zusammenlegen & einräumen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A15",
        icon: "🗄️",
        iconUrl: "assets/icons/icon_flu_schubladen.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_schubladen.png",
        leftPct: 23.80, topPct: 58.00, widthPct: 33.00, heightPct: 10.20, zIndex: 13,
        mb: 0, xp: 50, gold: 10, ap: 1,
        repr: "Weiße und dunkelgrüne Schubladen im Flur"
      },
      {
        id: "FLU_005_01",
        raum: "Flur",
        name: "Ronja zum Kindergarten bringen",
        anzeigeName: "Postkarten & Familienzettel an der Kork-Pinnwand (Ronja zum Kindergarten bringen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A2",
        icon: "📌",
        iconUrl: "assets/icons/icon_flu_pinnwand_tuer.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_pinnwand_tuer.png",
        leftPct: 82.50, topPct: 38.50, widthPct: 16.50, heightPct: 7.10, zIndex: 16,
        mb: 0, xp: 10, gold: 1, ap: 1,
        repr: "Notizen & Postkarten an der Kork-Pinnwand rechts"
      },
      {
        id: "FLU_006_01",
        raum: "Flur",
        name: "Mittagsspaziergang",
        anzeigeName: "Holz-Schlüsselschale mit Sonnenbrille, Schlüssel & Portemonnaie (Mittagsspaziergang)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A42",
        icon: "🕶️",
        iconUrl: "assets/icons/icon_flu_schluesselschale.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_schluesselschale.png",
        leftPct: 3.50, topPct: 61.80, widthPct: 21.00, heightPct: 6.58, zIndex: 18,
        mb: 2, xp: 125, gold: 0, ap: 1,
        repr: "Sonnenbrille, Hausschlüssel & Portemonnaie auf der Kommode"
      },
      {
        id: "FLU_007_01",
        raum: "Flur",
        name: "Ronja vom Kindergarten abholen",
        anzeigeName: "Kinderjacke & Einkaufstasche an der Garderobe (Ronja abholen / Einkaufen gehen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A3",
        icon: "🧥",
        iconUrl: "assets/icons/icon_flu_garderobe.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_garderobe.png",
        leftPct: 51.50, topPct: 45.00, widthPct: 15.50, heightPct: 9.61, zIndex: 17,
        mb: 0, xp: 15, gold: 1, ap: 1,
        repr: "Kinderjacke & Einkaufstasche an der Flurgarderobe"
      },
      {
        id: "FLU_008_01",
        raum: "Flur",
        name: "Bauprojekt Schlafzimmerempore und Flurebene",
        anzeigeName: "Holz-Werkzeugkasten, Akkuschrauber, Bauplan & Sneaker (Bauprojekt Flurebene)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A42",
        icon: "🧰",
        iconUrl: "assets/icons/icon_flu_werkzeug_schuhe.png",
        spriteUrl: "assets/flur_sprites/sprite_flu_werkzeug_schuhe.png",
        leftPct: 64.50, topPct: 81.50, widthPct: 25.00, heightPct: 9.28, zIndex: 18,
        mb: 3, xp: 1000, gold: 1000, ap: 2,
        repr: "Werkzeugkasten mit Bauplan, Zollstock, Akkuschrauber & Sneakern"
      },
      {
        id: "FLU_MAP",
        raum: "Flur",
        name: "Wohnungs-Grundriss öffnen",
        anzeigeName: "Holztür im Flur (Zur Wohnungs-Map)",
        zielTabelle: "Navigation",
        icon: "🗺️",
        spriteUrl: "assets/flur_sprites/sprite_flu_tuer_durchgang.png",
        leftPct: 62.80, topPct: 34.20, widthPct: 14.70, heightPct: 39.00, zIndex: 11,
        isMapDoor: true
      }
    ],
    "Dashboard": [
      {
        id: "DASH_001_PINNWAND",
        raum: "Dashboard",
        name: "Etwas tun, was einem sonst nicht leicht fällt",
        anzeigeName: "Kork-Pinnwand (Plan A, Map & Budget-Übersicht)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A32",
        icon: "📋",
        iconUrl: "assets/icons/icon_dash_klemmbrett_todo.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_pinnwand.png",
        leftPct: 9.00, topPct: 16.50, widthPct: 60.00, heightPct: 25.28, zIndex: 12,
        xPct: 39.0, yPct: 29.1,
        mb: 1, xp: 300, gold: 0, ap: 1,
        repr: "Klemmbrett mit abgehakter To-Do-Liste an der Korkwand"
      },
      {
        id: "DASH_002_GOALS",
        raum: "Dashboard",
        name: "Vorbereitung auf Vorstellungsgespräch",
        anzeigeName: "GOALS-Checkliste & Wandcharts (Gesprächsvorbereitung)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A39",
        icon: "🎯",
        iconUrl: "assets/icons/icon_dash_interview_prep.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_goals.png",
        leftPct: 39.00, topPct: 42.50, widthPct: 29.00, heightPct: 14.68, zIndex: 13,
        xPct: 53.5, yPct: 49.8,
        mb: 0, xp: 50, gold: 125, ap: 1,
        repr: "Klemmbrett mit Fragen & Notizblock"
      },
      {
        id: "DASH_003_LAMPE",
        raum: "Dashboard",
        name: "Vibe Coding",
        anzeigeName: "Schreibtischlampe (Vibe Coding Fokus-Session)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A45",
        icon: "💡",
        iconUrl: "assets/icons/icon_dash_vibecoding.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_lampe.png",
        leftPct: 15.00, topPct: 46.50, widthPct: 23.50, heightPct: 14.73, zIndex: 14,
        xPct: 26.8, yPct: 53.9,
        mb: 2, xp: 500, gold: 0, ap: 1,
        repr: "Coding-Kopfhörer & beleuchtete mechanische Tastatur"
      },
      {
        id: "DASH_004_ORGANIZER",
        raum: "Dashboard",
        name: "Täglicher Check AfA Bewerbungen",
        anzeigeName: "Leder-Stifteorganizer (Täglicher Check AfA Bewerbungen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A35",
        icon: "✒️",
        iconUrl: "assets/icons/icon_dash_afa_check.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_organizer.png",
        leftPct: 15.50, topPct: 59.80, widthPct: 17.50, heightPct: 7.16, zIndex: 16,
        xPct: 24.3, yPct: 63.4,
        mb: 1, xp: 25, gold: 50, ap: 1,
        repr: "Schreibtisch-Organizer & AfA-Unterlagen"
      },
      {
        id: "DASH_005_RECHNER",
        raum: "Dashboard",
        name: "Rechnungen bezahlen oder Formulare richtig ausfüllen und abschicken",
        anzeigeName: "Taschenrechner & Briefstapel (Rechnungen & Formulare)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A21",
        icon: "🧮",
        iconUrl: "assets/icons/icon_dash_rechnungen.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_rechner.png",
        leftPct: 31.00, topPct: 59.20, widthPct: 16.00, heightPct: 7.87, zIndex: 17,
        xPct: 39.0, yPct: 63.1,
        mb: -2, xp: 300, gold: 0, ap: 3,
        repr: "Briefstapel & Taschenrechner am Schreibtisch"
      },
      {
        id: "DASH_SHOP",
        raum: "Dashboard",
        name: "Shop öffnen",
        anzeigeName: "Rosa Sparschwein (Dopamin-Shop & Belohnungen öffnen)",
        zielTabelle: "Shop",
        icon: "🐷",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_sparschwein.png",
        leftPct: 42.00, topPct: 52.80, widthPct: 20.00, heightPct: 9.86, zIndex: 18,
        xPct: 52.0, yPct: 57.7,
        isShopTrigger: true
      },
      {
        id: "DASH_007_ROBOTER",
        raum: "Dashboard",
        name: "ADHD Quest programmieren",
        anzeigeName: "Holz-Roboter auf dem Schreibtisch (ADHD Quest programmieren)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A40",
        icon: "🤖",
        iconUrl: "assets/icons/icon_dash_adhdquest_code.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_roboter.png",
        leftPct: 63.50, topPct: 50.20, widthPct: 14.50, heightPct: 10.59, zIndex: 17,
        xPct: 70.8, yPct: 55.5,
        mb: 1, xp: 500, gold: 0, ap: 1,
        repr: "Offener Laptop & Roboter-Figur auf dem Schreibtisch"
      },
      {
        id: "DASH_008_NOTIZBUCH",
        raum: "Dashboard",
        name: "Tägliche Recherche Jobbörsen (20 min)",
        anzeigeName: "Aufgeschlagenes Notizbuch (Recherche Jobbörsen / Deprexis)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A36",
        icon: "📖",
        iconUrl: "assets/icons/icon_dash_jobboersen.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_notizbuch.png",
        leftPct: 56.50, topPct: 59.80, widthPct: 22.00, heightPct: 7.48, zIndex: 16,
        xPct: 67.5, yPct: 63.5,
        mb: 1, xp: 25, gold: 50, ap: 1,
        repr: "Laptop auf dem Schreibtisch mit Jobbörsen-Tabs"
      },
      {
        id: "DASH_009_ISTQB",
        raum: "Dashboard",
        name: "Lernen für ISTQB (Softwaretesting) 30 min",
        anzeigeName: "Bunter Bücherstapel am Teppich (ISTQB Foundation Level)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A37",
        icon: "📚",
        iconUrl: "assets/icons/icon_dash_istqb_buch.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_istqb_stapel.png",
        leftPct: 52.00, topPct: 82.50, widthPct: 21.00, heightPct: 11.22, zIndex: 19,
        xPct: 62.5, yPct: 88.1,
        mb: 0, xp: 50, gold: 100, ap: 3,
        repr: "ISTQB-Lehrbuch & Textmarker am Schreibtisch"
      },
      {
        id: "DASH_010_KOFFER",
        raum: "Dashboard",
        name: "Bewerbung geschrieben und abgeschickt",
        anzeigeName: "Reisekoffer unten rechts (Bewerbung abgeschickt!)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A41",
        icon: "🧳",
        iconUrl: "assets/icons/icon_dash_bewerbungsmappe.png",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_koffer.png",
        leftPct: 71.50, topPct: 79.50, widthPct: 26.50, heightPct: 13.95, zIndex: 18,
        xPct: 84.8, yPct: 86.5,
        mb: 2, xp: 500, gold: 300, ap: 3,
        repr: "Versandbereite Bewerbungsmappe am Schreibtisch"
      },
      {
        id: "DASH_DOOR",
        raum: "Dashboard",
        name: "Zur Wohnungs-Map",
        anzeigeName: "Offene Holztür rechts (Zur Wohnungs-Map)",
        zielTabelle: "Navigation",
        icon: "🚪",
        spriteUrl: "assets/dashboard_sprites/sprite_dash_tuer.png",
        leftPct: 74.22, topPct: 29.36, widthPct: 25.78, heightPct: 45.49, zIndex: 11,
        xPct: 87.1, yPct: 52.1,
        isMapDoor: true
      }
    ],
    "Wohnzimmer": [
      {
        id: "WOH_001_STAGEPIANO",
        raum: "Wohnzimmer",
        name: "Klavier spielen (20 min)",
        anzeigeName: "Stage Piano in der Musikecke (Klavier spielen – 20 min)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A33",
        icon: "🎹",
        iconUrl: "assets/icons/icon_woh_stagepiano.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_stagepiano.png",
        leftPct: 54.00, topPct: 51.00, widthPct: 28.50, heightPct: 11.50, zIndex: 15,
        xPct: 68.3, yPct: 56.8,
        mb: 3, xp: 15, gold: 0, ap: 1,
        repr: "Stage Piano in der Musikecke"
      },
      {
        id: "WOH_002_SYNTH",
        raum: "Wohnzimmer",
        name: "Ein Instrument spielen oder neu lernen (30 min)",
        anzeigeName: "Synthesizer & Studio-Desk (Instrument spielen/lernen – 30 min)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A19",
        icon: "🎛️",
        iconUrl: "assets/icons/icon_woh_synth_piano.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_synth_piano.png",
        leftPct: 60.50, topPct: 43.50, widthPct: 16.00, heightPct: 6.70, zIndex: 16,
        xPct: 68.5, yPct: 46.9,
        mb: 1, xp: 25, gold: 0, ap: 0,
        repr: "Stage Piano & Synthesizer"
      },
      {
        id: "WOH_003_UKULELEN",
        raum: "Wohnzimmer",
        name: "Trommeln oder ein anderes Instrument spielen",
        anzeigeName: "Ukulelen an der Ziegelwand (Instrument spielen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A10",
        icon: "🎸",
        iconUrl: "assets/icons/icon_woh_ukulelen.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_ukulelen.png",
        leftPct: 78.50, topPct: 35.00, widthPct: 7.00, heightPct: 12.80, zIndex: 14,
        xPct: 82.0, yPct: 41.4,
        mb: 2, xp: 25, gold: 0, ap: 0,
        repr: "Ukulele an der Wand oder Trommel"
      },
      {
        id: "WOH_004_MONITORBOXEN",
        raum: "Wohnzimmer",
        name: "Schöne Musik hören",
        anzeigeName: "Studio-Monitorboxen auf dem Wandregal (Schöne Musik hören)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A2",
        icon: "🎧",
        iconUrl: "assets/icons/icon_woh_monitorboxen.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_monitorboxen.png",
        leftPct: 54.50, topPct: 34.20, widthPct: 26.00, heightPct: 5.30, zIndex: 14,
        xPct: 67.5, yPct: 36.9,
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Schallplattenspieler, Kopfhörer oder Monitor-Boxen"
      },
      {
        id: "WOH_005_FOTOALBUM",
        raum: "Wohnzimmer",
        name: "Gemeinsam mit jemandem lachen",
        anzeigeName: "Geöffnetes Fotoalbum auf dem Couchtisch (Gemeinsam lachen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A23",
        icon: "📗",
        iconUrl: "assets/icons/icon_woh_fotoalbum.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_fotoalbum.png",
        leftPct: 43.00, topPct: 65.80, widthPct: 19.50, heightPct: 8.59, zIndex: 18,
        xPct: 52.8, yPct: 70.1,
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Geöffnetes Fotoalbum auf dem Couchtisch"
      },
      {
        id: "WOH_006_SOFAKISSEN",
        raum: "Wohnzimmer",
        name: "Auf einer Bank sitzen.",
        anzeigeName: "Sitz-Fensterbank & karminrotes Sofa mit Kissen (Ausruhen / Innehalten)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A15",
        icon: "🛋️",
        iconUrl: "assets/icons/icon_woh_sofakissen.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_sofakissen.png",
        leftPct: 2.50, topPct: 47.00, widthPct: 29.50, heightPct: 15.80, zIndex: 13,
        xPct: 17.3, yPct: 54.9,
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Gemütliches Kissen auf der Fensterbank / Sofa"
      },
      {
        id: "WOH_007_TEETASSEN",
        raum: "Wohnzimmer",
        name: "Sich mit einem Menschen, den man mag, unterhalten",
        anzeigeName: "Zwei dampfende Teetassen auf dem Couchtisch (Gutes Gespräch führen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A22",
        icon: "☕",
        iconUrl: "assets/icons/icon_woh_teetassen.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_teetassen.png",
        leftPct: 45.50, topPct: 60.50, widthPct: 16.00, heightPct: 8.01, zIndex: 17,
        xPct: 53.5, yPct: 64.5,
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Zwei dampfende Teetassen auf dem Couchtisch"
      },
      {
        id: "WOH_008_GAMEPADS",
        raum: "Wohnzimmer",
        name: "Mit Pia Rimworld spielen",
        anzeigeName: "Zwei Gamepads auf dem weißen Kallax-Regal (Mit Pia Rimworld spielen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A39",
        icon: "🎮",
        iconUrl: "assets/icons/icon_woh_gamepads.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_gamepads.png",
        leftPct: 67.50, topPct: 80.50, widthPct: 18.00, heightPct: 7.59, zIndex: 19,
        xPct: 76.5, yPct: 84.3,
        mb: 2, xp: 125, gold: 0, ap: 0,
        repr: "Zwei Gamepads am Kallax-Regal"
      },
      {
        id: "WOH_009_FERNSEHER",
        raum: "Wohnzimmer",
        name: "Einen guten Film angucken",
        anzeigeName: "Fernseher rechts auf dem Kallax-Regal (Einen guten Film angucken)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A11",
        icon: "🎬",
        iconUrl: "assets/icons/icon_woh_fernseher.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_fernseher.png",
        leftPct: 82.50, topPct: 66.00, widthPct: 17.50, heightPct: 19.00, zIndex: 18,
        xPct: 91.3, yPct: 75.5,
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Fernseher oder Popcorn-Schüssel"
      },
      {
        id: "WOH_010_WANDFOKUS",
        raum: "Wohnzimmer",
        name: "Stare at the Wall (10 min)",
        anzeigeName: "Kronleuchter & Wandfokus (Stare at the Wall – 10 min)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A40",
        icon: "🕯️",
        iconUrl: "assets/icons/icon_woh_wandfokus.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_wandfokus.png",
        leftPct: 11.00, topPct: 3.80, widthPct: 20.50, heightPct: 15.20, zIndex: 12,
        xPct: 21.3, yPct: 11.4,
        mb: 2, xp: 125, gold: 100, ap: 1,
        repr: "Leere weiße Wand gegenüber dem Sessel"
      },
      {
        id: "WOH_AUF_001",
        raum: "Wohnzimmer",
        name: "Samstagsputz (Wohnzimmer)",
        anzeigeName: "Staubsauger & Mikrofasertuch am Teppich (Samstagsputz Wohnzimmer)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A8",
        leftPct: 26.50, topPct: 74.50, widthPct: 23.50, heightPct: 12.49, zIndex: 17,
        xPct: 38.3, yPct: 80.7,
        icon: "🧹",
        iconUrl: "assets/icons/icon_woh_staubsauger.png",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_staubsauger.png",
        mb: 0, xp: 125, gold: 50, ap: 2,
        repr: "Staubsauger & Mikrofasertuch"
      },
      {
        id: "WOH_DOOR",
        raum: "Wohnzimmer",
        name: "Zur Wohnungs-Map",
        anzeigeName: "Wohnzimmertür hinten links (Zur Wohnungs-Map)",
        zielTabelle: "Navigation",
        icon: "🚪",
        spriteUrl: "assets/wohnzimmer_sprites/sprite_woh_tuer.png",
        leftPct: 24.20, topPct: 35.00, widthPct: 22.60, heightPct: 26.20, zIndex: 11,
        xPct: 35.5, yPct: 48.1,
        isMapDoor: true
      }
    ],
    "Küche": [
      {
        id: "KUE_001_01",
        raum: "Küche",
        name: "Geschirrspüler ausräumen und einräumen",
        anzeigeName: "Geschirrspüler ausräumen und einräumen",
        zielTabelle: "Aufgaben",
        verknuepfung: "A13",
        posX: -0.57, posY: 0.351,
        leftPct: 2.80, topPct: 58.20, widthPct: 20.50, heightPct: 13.80, zIndex: 15,
        xPct: 13.0, yPct: 65.0,
        icon: "🍽️",
        iconUrl: "assets/icons/icon_kue_001.png",
        spriteUrl: "assets/kueche_sprites/sprite_kue_geschirrspueler.png",
        soundUrl: "https://raw.githubusercontent.com/SokratesSchmitt/ADHD-Quest/main/sounds/sfx_kue_001.mp3",
        iconName: "icon_kue_001.png",
        soundName: "sfx_kue_001.mp3",
        mb: 0, xp: 125, gold: 10, ap: 1,
        repr: "Geschirrspüler"
      },
      {
        id: "KUE_002_01",
        raum: "Küche",
        name: "Tisch abwischen",
        anzeigeName: "Obstschale & Tisch-Reinigungsset (Tisch abwischen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A17",
        posX: -0.21, posY: 0.597,
        leftPct: 41.00, topPct: 64.50, widthPct: 24.50, heightPct: 11.00, zIndex: 17,
        xPct: 53.3, yPct: 70.0,
        icon: "🧽",
        iconUrl: "assets/icons/icon_kue_putzeimer.png",
        spriteUrl: "assets/kueche_sprites/sprite_kue_obst_putzset.png",
        soundUrl: "https://raw.githubusercontent.com/SokratesSchmitt/ADHD-Quest/main/sounds/sfx_kue_002.mp3",
        iconName: "icon_kue_002.png",
        soundName: "sfx_kue_002.mp3",
        mb: 0, xp: 5, gold: 5, ap: 1,
        repr: "Küchentisch / Arbeitsfläche"
      },
      {
        id: "KUE_003_01",
        raum: "Küche",
        name: "Mittagessen vorbereiten",
        anzeigeName: "Schneidebrett, Kochmesser & Kupfertopf (Mittagessen vorbereiten)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A11",
        posX: -0.10, posY: -0.465,
        leftPct: 12.50, topPct: 42.50, widthPct: 25.00, heightPct: 11.46, zIndex: 16,
        xPct: 25.0, yPct: 48.2,
        icon: "🍳",
        iconUrl: "assets/icons/icon_kue_schneidebrett_topf.png",
        spriteUrl: "assets/kueche_sprites/sprite_kue_schneidebrett_topf.png",
        soundUrl: "https://raw.githubusercontent.com/SokratesSchmitt/ADHD-Quest/main/sounds/sfx_kue_003.mp3",
        iconName: "icon_kue_003.png",
        soundName: "sfx_kue_003.mp3",
        mb: 0, xp: 125, gold: 1, ap: 1,
        repr: "Holz-Schneidebrett / Herd"
      },
      {
        id: "KUE_AUF_004",
        raum: "Küche",
        name: "Müll rausbringen",
        anzeigeName: "Mülleimer-Trennsystem & Putzeimer (Müll rausbringen / Samstagsputz)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A14",
        leftPct: 35.00, topPct: 52.50, widthPct: 22.50, heightPct: 9.06, zIndex: 14,
        xPct: 46.3, yPct: 57.0,
        icon: "🗑️",
        iconUrl: "assets/icons/icon_kue_muelleimer.png",
        spriteUrl: "assets/kueche_sprites/sprite_kue_muelleimer.png",
        mb: 0, xp: 125, gold: 10, ap: 1,
        repr: "Mülleimer-Trennsystem unter der Spüle"
      },
      {
        id: "KUE_MB_001",
        raum: "Küche",
        name: "Leckeres Essen zubereiten",
        anzeigeName: "Siebträger-Kaffeemaschine & Coffee-to-go (Genuss & Kompetenz)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A4",
        leftPct: 2.00, topPct: 44.50, widthPct: 18.00, heightPct: 10.90, zIndex: 17,
        xPct: 11.0, yPct: 50.0,
        icon: "☕",
        iconUrl: "assets/icons/icon_kue_siebtraeger.png",
        spriteUrl: "assets/kueche_sprites/sprite_kue_siebtraeger.png",
        mb: 1, xp: 15, gold: 0, ap: 0,
        repr: "Siebträgermaschine & Lieblings-Kaffeetasse"
      },
      {
        id: "KUE_MB_002",
        raum: "Küche",
        name: "Zentangle (10 min)",
        anzeigeName: "Zentangle-Skizzenblock & Fineliner (10 min Fokus & Entspannung)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A37",
        leftPct: 68.00, topPct: 66.50, widthPct: 25.50, heightPct: 11.52, zIndex: 18,
        xPct: 80.8, yPct: 72.3,
        icon: "✒️",
        iconUrl: "assets/icons/icon_kue_zentangle.png",
        spriteUrl: "assets/kueche_sprites/sprite_kue_zentangle.png",
        mb: 1, xp: 50, gold: 0, ap: 0,
        repr: "Skizzenblock und schwarzer Fineliner"
      },
      {
        id: "KUE_DOOR",
        raum: "Küche",
        name: "Zur Wohnungs-Map",
        anzeigeName: "Offene Küchentür rechts (Zur Wohnungs-Map)",
        zielTabelle: "Navigation",
        leftPct: 84.50, topPct: 24.50, widthPct: 15.50, heightPct: 44.00, zIndex: 12,
        xPct: 92.3, yPct: 46.5,
        icon: "🚪",
        spriteUrl: "assets/kueche_sprites/sprite_kue_tuer.png",
        isMapDoor: true
      }
    ],
    "Schlafzimmer": [
      {
        id: "SCH_MB_001",
        raum: "Schlafzimmer",
        name: "Eine Massage bekommen oder jemanden massieren",
        anzeigeName: "Massageöl & Spa-Handtuch auf dem Sideboard (Massage bekommen / massieren)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A3",
        leftPct: 81.00, topPct: 50.50, widthPct: 16.50, heightPct: 9.69, zIndex: 17,
        xPct: 89.3, yPct: 55.3,
        icon: "💆",
        iconUrl: "assets/icons/icon_sch_massageoel.png",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_massageoel.png",
        mb: 2, xp: 5, gold: 0, ap: 0,
        repr: "Fläschchen Massageöl & Handtuch"
      },
      {
        id: "SCH_MB_002",
        raum: "Schlafzimmer",
        name: "Mit jemandem zärtlich sein",
        anzeigeName: "Rostorange & senfgelbe Kissen auf dem Bett (Mit jemandem zärtlich sein)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A8",
        leftPct: 3.80, topPct: 53.00, widthPct: 25.70, heightPct: 11.20, zIndex: 13,
        xPct: 16.7, yPct: 58.6,
        icon: "🕯️",
        iconUrl: "assets/icons/icon_sch_kissen.png",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_kissen.png",
        mb: 2, xp: 25, gold: 0, ap: 0,
        repr: "Besondere Kissen auf dem Bett"
      },
      {
        id: "SCH_MB_003",
        raum: "Schlafzimmer",
        name: "Nachts ganz bewusst den Mond und die Sterne betrachten",
        anzeigeName: "Messing-Teleskop im Bücher-Erker (Mond und Sterne betrachten)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A13",
        leftPct: 50.00, topPct: 46.80, widthPct: 13.80, heightPct: 12.70, zIndex: 14,
        xPct: 56.9, yPct: 53.2,
        icon: "🔭",
        iconUrl: "assets/icons/icon_sch_teleskop.png",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_teleskop.png",
        mb: 2, xp: 5, gold: 0, ap: 0,
        repr: "Teleskop am Erkerfenster"
      },
      {
        id: "SCH_MB_004",
        raum: "Schlafzimmer",
        name: "Sich sportlich betätigen",
        anzeigeName: "Ausgerollte Yogamatte & Hanteln am Teppich (Sich sportlich betätigen / Planking)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A29",
        leftPct: 49.00, topPct: 70.50, widthPct: 29.00, heightPct: 11.20, zIndex: 18,
        xPct: 63.5, yPct: 76.1,
        icon: "🧘",
        iconUrl: "assets/icons/icon_sch_yogamatte.png",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_yogamatte.png",
        mb: 2, xp: 25, gold: 0, ap: 0,
        repr: "Ausgerollte Yogamatte & Hanteln"
      },
      {
        id: "SCH_MB_005",
        raum: "Schlafzimmer",
        name: "10000 Schritte gehen",
        anzeigeName: "Paar Laufschuhe auf der Holzbank (10.000 Schritte gehen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A16",
        leftPct: 24.00, topPct: 77.20, widthPct: 20.50, heightPct: 7.91, zIndex: 19,
        xPct: 34.3, yPct: 81.2,
        icon: "👟",
        iconUrl: "assets/icons/icon_sch_laufschuhe.png",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_laufschuhe.png",
        mb: 2, xp: 50, gold: 0, ap: 0,
        repr: "Paar Laufschuhe im Vordergrund"
      },
      {
        id: "SCH_MB_006",
        raum: "Schlafzimmer",
        name: "Eigene Stärken und Talente bewusst machen... Liste oder Test absolvieren",
        anzeigeName: "Aufgeschlagenes Journal auf dem vorderen Nachttisch (Eigene Stärken bewusst machen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A26",
        leftPct: 0.50, topPct: 62.80, widthPct: 17.00, heightPct: 7.20, zIndex: 15,
        xPct: 9.0, yPct: 66.4,
        icon: "📓",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_journal.png",
        mb: 1, xp: 15, gold: 0, ap: 0,
        repr: "Aufgeschlagenes Journal auf dem Nachttisch"
      },
      {
        id: "SCH_MB_007",
        raum: "Schlafzimmer",
        name: "Mit jemandem Sex haben",
        anzeigeName: "Brennende Kerzen auf dem hinteren Nachttisch (Zweisamkeit & Intimität)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A24",
        leftPct: 22.50, topPct: 53.20, widthPct: 10.30, heightPct: 5.00, zIndex: 14,
        xPct: 27.7, yPct: 55.7,
        icon: "🕯️",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_kerzen.png",
        mb: 2, xp: 25, gold: 0, ap: 0,
        repr: "Kerzen am Bett"
      },
      {
        id: "SCH_AUF_001",
        raum: "Schlafzimmer",
        name: "Samstagsputz (Schlafzimmer)",
        anzeigeName: "Staubwedel & frische Bettwäsche (Samstagsputz Schlafzimmer)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A9",
        leftPct: 44.50, topPct: 56.50, widthPct: 20.00, heightPct: 10.54, zIndex: 17,
        xPct: 54.5, yPct: 61.8,
        icon: "🛏️",
        iconUrl: "assets/icons/icon_sch_samstagsputz.png",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_samstagsputz.png",
        mb: 0, xp: 150, gold: 50, ap: 2,
        repr: "Frische Bettwäsche & Staubwedel"
      },
      {
        id: "SCH_DOOR",
        raum: "Schlafzimmer",
        name: "Zur Wohnungs-Map",
        anzeigeName: "Schlafzimmertür rechts (Zur Wohnungs-Map)",
        zielTabelle: "Navigation",
        leftPct: 65.00, topPct: 34.50, widthPct: 25.00, heightPct: 28.00, zIndex: 11,
        xPct: 77.5, yPct: 48.5,
        icon: "🚪",
        spriteUrl: "assets/schlafzimmer_sprites/sprite_sch_tuer.png",
        isMapDoor: true
      }
    ],
    "Badezimmer": [
      {
        id: "BAD_MB_001",
        raum: "Badezimmer",
        name: "Schwimmen",
        anzeigeName: "Gepackte Badetasche mit Handtuch & Schwimmbrille (Schwimmen gehen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A5",
        leftPct: 26.00, topPct: 75.50, widthPct: 25.50, heightPct: 12.73, zIndex: 18,
        xPct: 38.8, yPct: 81.9,
        icon: "🏊",
        iconUrl: "assets/icons/icon_bad_badetasche.png",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_badetasche.png",
        mb: 5, xp: 25, gold: 0, ap: 0,
        repr: "Fertig gepackte Badetasche mit Handtuch"
      },
      {
        id: "BAD_MB_002",
        raum: "Badezimmer",
        name: "Kalt duschen",
        anzeigeName: "Glasdusche mit Regenduschkopf (Kalt duschen – Erfrischung & Fokus)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A34",
        leftPct: 50.80, topPct: 32.00, widthPct: 25.70, heightPct: 33.80, zIndex: 12,
        xPct: 63.7, yPct: 48.9,
        icon: "🚿",
        iconUrl: "assets/icons/icon_bad_kaltduschen.png",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_dusche.png",
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Regenduschkopf in der Glasdusche"
      },
      {
        id: "BAD_MB_003",
        raum: "Badezimmer",
        name: "Venla",
        anzeigeName: "Pillendose & Wasserglas am Waschtisch (Venla – Tägliche Medikations-Routine)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A38",
        leftPct: 73.50, topPct: 52.80, widthPct: 18.00, heightPct: 6.00, zIndex: 17,
        xPct: 82.5, yPct: 55.8,
        icon: "💊",
        iconUrl: "assets/icons/icon_bad_venla.png",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_venla.png",
        mb: 2, xp: 50, gold: 0, ap: 0,
        repr: "Pillendose auf der Bad-Ablage"
      },
      {
        id: "BAD_MB_004",
        raum: "Badezimmer",
        name: "Sich bewusst werden, dass die eigenen Schwächen oder Fehler auch nur menschlich sind.",
        anzeigeName: "Spiegel über dem Waschbecken (Selbstmitgefühl & Achtsamkeit)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A27",
        leftPct: 83.80, topPct: 31.80, widthPct: 14.00, heightPct: 24.70, zIndex: 13,
        xPct: 90.8, yPct: 44.2,
        icon: "🪞",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_spiegel.png",
        mb: 1, xp: 15, gold: 0, ap: 0,
        repr: "Spiegel über dem Waschbecken"
      },
      {
        id: "BAD_AUF_001",
        raum: "Badezimmer",
        name: "Wäsche waschen",
        anzeigeName: "Wäschekorb & Waschpulver vor der Waschmaschine (Wäsche waschen / ausräumen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A4",
        leftPct: 19.50, topPct: 63.50, widthPct: 22.00, heightPct: 9.89, zIndex: 16,
        xPct: 30.5, yPct: 68.4,
        icon: "🧺",
        iconUrl: "assets/icons/icon_bad_waschmaschine.png",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_waeschekorb.png",
        mb: 0, xp: 50, gold: 25, ap: 1,
        repr: "Wäschekorb & Waschpulver vor der Waschmaschine"
      },
      {
        id: "BAD_AUF_002",
        raum: "Badezimmer",
        name: "Samstagsputz (Bad)",
        anzeigeName: "Badreiniger, Schwamm & Abzieher (Samstagsputz Bad)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A10",
        leftPct: 55.50, topPct: 69.50, widthPct: 18.00, heightPct: 9.46, zIndex: 17,
        xPct: 64.5, yPct: 74.2,
        icon: "✨",
        iconUrl: "assets/icons/icon_bad_badreiniger.png",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_badreiniger.png",
        mb: 0, xp: 125, gold: 50, ap: 2,
        repr: "Badreiniger, Schwamm & Abzieher"
      },
      {
        id: "BAD_AUF_003",
        raum: "Badezimmer",
        name: "Trockner ausräumen und Wäsche zusammenlegen",
        anzeigeName: "Frisch zusammengelegte Handtücher auf der Holzplatte (Trockner ausräumen & zusammenlegen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A6",
        leftPct: 10.50, topPct: 49.80, widthPct: 17.50, heightPct: 9.60, zIndex: 16,
        xPct: 19.3, yPct: 54.6,
        icon: "🧖",
        iconUrl: "assets/icons/icon_bad_handtuecher.png",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_handtuecher.png",
        mb: 0, xp: 50, gold: 25, ap: 2,
        repr: "Zusammengelegte Handtücher über der Waschmaschine"
      },
      {
        id: "BAD_DOOR",
        raum: "Badezimmer",
        name: "Zur Wohnungs-Map",
        anzeigeName: "Badezimmertür hinten links (Zur Wohnungs-Map)",
        zielTabelle: "Navigation",
        leftPct: 24.50, topPct: 35.20, widthPct: 22.30, heightPct: 26.30, zIndex: 11,
        xPct: 35.7, yPct: 48.4,
        icon: "🚪",
        spriteUrl: "assets/badezimmer_sprites/sprite_bad_tuer.png",
        isMapDoor: true
      }
    ],
    "Kinderzimmer": [
      {
        id: "KIN_MB_001",
        raum: "Kinderzimmer",
        name: "Mit Kindern spielen",
        anzeigeName: "Bunte Holzeisenbahn auf dem Spielteppich (Mit Kindern spielen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A14",
        leftPct: 15.50, topPct: 74.20, widthPct: 48.70, heightPct: 16.60, zIndex: 17,
        xPct: 39.9, yPct: 82.5,
        icon: "🚂",
        iconUrl: "assets/icons/icon_kin_eisenbahn_einhorn.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_eisenbahn.png",
        mb: 1, xp: 25, gold: 0, ap: 0,
        repr: "Bunte Spielzeug-Eisenbahn auf dem Teppich"
      },
      {
        id: "KIN_MB_002",
        raum: "Kinderzimmer",
        name: "Etwas basteln oder bauen (30 min)",
        anzeigeName: "Kleiner Mal- & Basteltisch mit Buntstiften (30 min basteln/bauen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A20",
        leftPct: 62.20, topPct: 58.50, widthPct: 36.30, heightPct: 21.00, zIndex: 16,
        xPct: 80.4, yPct: 69.0,
        icon: "🎨",
        iconUrl: "assets/icons/icon_kin_basteltisch.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_basteltisch.png",
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Kleiner Mal- & Basteltisch"
      },
      {
        id: "KIN_MB_003",
        raum: "Kinderzimmer",
        name: "Handwerken (Holz)",
        anzeigeName: "Holz-Werkzeugkasten mit Japansäge, Hammer & Stecheisen (Handwerken / Holz)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A44",
        leftPct: 64.20, topPct: 78.80, widthPct: 35.60, heightPct: 21.00, zIndex: 19,
        xPct: 82.0, yPct: 89.3,
        icon: "🪚",
        iconUrl: "assets/icons/icon_kin_holzwerkzeug.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_werkzeugkasten.png",
        mb: 3, xp: 500, gold: 0, ap: 1,
        repr: "Holz-Werkzeugkasten mit Japansäge & Stecheisen"
      },
      {
        id: "KIN_MB_004",
        raum: "Kinderzimmer",
        name: "Etwas tun, worauf ich stolz bin (auch wenn es nur eine kleine Sache ist)",
        anzeigeName: "Gerahmtes „Gelato Girl“-Poster über dem Bett (Worauf ich stolz bin)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A28",
        leftPct: 55.40, topPct: 21.20, widthPct: 19.20, heightPct: 16.00, zIndex: 14,
        xPct: 65.0, yPct: 29.2,
        icon: "🌟",
        iconUrl: "assets/icons/icon_kin_poster.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_poster.png",
        mb: 1, xp: 15, gold: 0, ap: 0,
        repr: "Gerahmtes Gelato-Girl-Poster an der Wand"
      },
      {
        id: "KIN_MB_005",
        raum: "Kinderzimmer",
        name: "Klavier spielen (20 min)",
        anzeigeName: "Rotes Korg Minipiano (Musik machen & kreativ klimpern)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A33",
        leftPct: 13.80, topPct: 53.20, widthPct: 25.00, heightPct: 16.00, zIndex: 15,
        xPct: 26.3, yPct: 61.2,
        icon: "🎹",
        iconUrl: "assets/icons/icon_kin_korg_piano.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_korg_piano.png",
        mb: 3, xp: 15, gold: 0, ap: 1,
        repr: "Rotes Minipiano von Korg"
      },
      {
        id: "KIN_MB_006",
        raum: "Kinderzimmer",
        name: "Gemeinsam mit jemandem lachen",
        anzeigeName: "Großes Regenbogen-Plüsch-Einhorn auf dem Bodenbett (Quatsch machen & kuscheln)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A23",
        leftPct: 65.50, topPct: 37.80, widthPct: 20.70, heightPct: 13.20, zIndex: 15,
        xPct: 75.9, yPct: 44.4,
        icon: "🦄",
        iconUrl: "assets/icons/icon_kin_einhorn.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_einhorn.png",
        mb: 1, xp: 5, gold: 0, ap: 0,
        repr: "Großes Plüsch-Einhorn auf dem Bett"
      },
      {
        id: "KIN_MB_007",
        raum: "Kinderzimmer",
        name: "Jemandem sagen, dass man ihm oder ihr dankbar ist oder sie/ihn gern hat",
        anzeigeName: "IKEA-Wandregale voller Kinderbücher (Vorlesen & gemeinsame Zeit)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A25",
        leftPct: 12.20, topPct: 21.80, widthPct: 20.80, heightPct: 28.40, zIndex: 14,
        xPct: 22.6, yPct: 36.0,
        icon: "📚",
        iconUrl: "assets/icons/icon_kin_ikearegale.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_ikearegale.png",
        mb: 1, xp: 15, gold: 0, ap: 0,
        repr: "Weiße IKEA-Bücherleisten an der Wand"
      },
      {
        id: "KIN_AUF_001",
        raum: "Kinderzimmer",
        name: "Ronja ins Bett bringen",
        anzeigeName: "Aufgeschlagenes Gute-Nacht-Buch auf dem Bodenbett (Ronja ins Bett bringen)",
        zielTabelle: "Aufgaben",
        verknuepfung: "A16",
        leftPct: 68.50, topPct: 51.20, widthPct: 20.30, heightPct: 6.30, zIndex: 16,
        xPct: 78.7, yPct: 54.4,
        icon: "📖",
        iconUrl: "assets/icons/icon_kin_gutenachtbuch.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_gutenachtbuch.png",
        mb: 0, xp: 10, gold: 1, ap: 1,
        repr: "Gute-Nacht-Buch auf dem Kinderbett"
      },
      {
        id: "KIN_AUF_002",
        raum: "Kinderzimmer",
        name: "Zimmer oder Wohnung aufräumen (30 min)",
        anzeigeName: "Bunte Spielzeugkiste mit Kuscheltieren & Bauklötzen (Kinderzimmer aufräumen)",
        zielTabelle: "MB Aktivitaeten",
        verknuepfung: "A18",
        leftPct: 0.20, topPct: 81.20, widthPct: 29.00, heightPct: 18.60, zIndex: 18,
        xPct: 14.7, yPct: 90.5,
        icon: "🧸",
        iconUrl: "assets/icons/icon_kin_spielzeugkiste.png",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_spielzeugkiste.png",
        mb: 1, xp: 50, gold: 0, ap: 0,
        repr: "Bunte Spielzeugkiste im Vordergrund"
      },
      {
        id: "KIN_DOOR",
        raum: "Kinderzimmer",
        name: "Zur Wohnungs-Map",
        anzeigeName: "Kinderzimmertür links (Zur Wohnungs-Map)",
        zielTabelle: "Navigation",
        leftPct: 0.00, topPct: 9.80, widthPct: 10.80, heightPct: 61.70, zIndex: 11,
        xPct: 5.4, yPct: 40.7,
        icon: "🚪",
        spriteUrl: "assets/kinderzimmer_sprites/sprite_kin_tuer.png",
        isMapDoor: true
      }
    ]
  };

  // 3b. Backup der Werks-Koordinaten für den PC-Entwicklermodus (Reset-Funktion)
  const FACTORY_ROOM_OBJECTS = JSON.parse(JSON.stringify(ROOM_OBJECTS));
  const FACTORY_POSTIT_SLOTS = [
    { slotNr: 1, id: "POSTIT_SLOT_1", postitSprite: "assets/dashboard_sprites/sprite_dash_postit_1.png", leftPct: 24.5, topPct: 31.2, widthPct: 14.2, heightPct: 8.2, rotDeg: -3.0, zIndex: 22 },
    { slotNr: 2, id: "POSTIT_SLOT_2", postitSprite: "assets/dashboard_sprites/sprite_dash_postit_2.png", leftPct: 39.2, topPct: 31.4, widthPct: 14.2, heightPct: 8.2, rotDeg: 2.2,  zIndex: 22 },
    { slotNr: 3, id: "POSTIT_SLOT_3", postitSprite: "assets/dashboard_sprites/sprite_dash_postit_3.png", leftPct: 53.8, topPct: 31.0, widthPct: 14.2, heightPct: 8.2, rotDeg: -1.8, zIndex: 22 }
  ];
  const FACTORY_DOOR_CLEANING = JSON.parse(JSON.stringify(ASSETS.doorCleaningCoords));

  // 4. Tabellenblatt "Shop" (Exakt deine 6 Einträge und Preise aus A1:E17!)
  const SHOP_ITEMS = [
    { id: "SHOP_001", name: "Wow spielen", preisGold: 100, kostenAp: 1, status: false },
    { id: "SHOP_002", name: "XBOX spielen", preisGold: 100, kostenAp: 1, status: false },
    { id: "SHOP_003", name: "Steam spielen", preisGold: 100, kostenAp: 1, status: false },
    { id: "SHOP_004", name: "Viennese", preisGold: 150, kostenAp: 2, status: false },
    { id: "SHOP_005", name: "Effektpedal kaufen", preisGold: 10000, kostenAp: 0, status: false },
    { id: "SHOP_006", name: "Akai MPC Sample", preisGold: 30000, kostenAp: 0, status: false }
  ];

  // 5. Tabellenblatt "Achievements" (Exakt aus A1:E5!)
  const ACHIEVEMENTS = [
    { id: "ACH_1", name: "Beständiger Geist", bedingung: "Streak => 3", goldBonus: 300, xpBonus: 300, status: "" },
    { id: "ACH_2", name: "Wochenheld", bedingung: "Streak => 7", goldBonus: 500, xpBonus: 500, status: "" },
    { id: "ACH_3", name: "Monatsveteran", bedingung: "Streak => 30", goldBonus: 1000, xpBonus: 1000, status: "" },
    { id: "ACH_4", name: "Eine Arbeit vollendet, die mindestens 3 Schritte erforderte", bedingung: "Meilenstein", goldBonus: 200, xpBonus: 200, status: "JA" }
  ];


  // 5b. Vollständiger Katalog aus "MB Aktivitaeten" (42 Einträge) & "Aufgaben" (25 Einträge) inkl. Spalte M (Raum) & Spalte N (Repräsentiert durch)
  const DEFAULT_SHEET_CATALOG = {
    mbAktivitaeten: [
      {
            "id": "MB_A2",
            "cellRef": "A2",
            "name": "Schöne Musik hören",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Schallplattenspieler, Kopfhörer oder Monitor-Boxen",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A3",
            "cellRef": "A3",
            "name": "Eine Massage bekommen oder jemanden massieren",
            "mb": 2,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Fläschchen Massageöl auf dem Nachttisch",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A4",
            "cellRef": "A4",
            "name": "Leckeres Essen zubereiten",
            "mb": 1,
            "xp": 15,
            "gold": 0,
            "ap": 0,
            "raum": "Küche",
            "repraesentiertDurch": "Holz-Schneidebrett mit Messer oder Kochtopf",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A5",
            "cellRef": "A5",
            "name": "Schwimmen",
            "mb": 5,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Fertig gepackte Badetasche mit Handtuch",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A6",
            "cellRef": "A6",
            "name": "Witze anhören oder einfach nur so lachen",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Flur",
            "repraesentiertDurch": "Großes Bücher- & Brettspielregal (Star Wars & Witzebuch)",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A7",
            "cellRef": "A7",
            "name": "In ein Café gehen, etwas essen/trinken oder einfach nur Leute beobachten",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Küche",
            "repraesentiertDurch": "Coffee-to-go Becher auf der Arbeitsplatte",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A8",
            "cellRef": "A8",
            "name": "Mit jemandem zärtlich sein",
            "mb": 2,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Besonderes Kissen auf dem Bett",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A9",
            "cellRef": "A9",
            "name": "Barfuß auf Gras oder Sand gehen...um die Füße richtig zu spüren",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Flur",
            "repraesentiertDurch": "Abgestelltes Paar Schuhe neben der Wohnungstür",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A10",
            "cellRef": "A10",
            "name": "Trommeln oder ein anderes Instrument spielen",
            "mb": 2,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Ukulele an der Wand oder Trommel",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A11",
            "cellRef": "A11",
            "name": "Einen guten Film angucken",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Fernseher oder Popcorn-Schüssel",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A12",
            "cellRef": "A12",
            "name": "In ein Restaurant gehen und gut essen",
            "mb": 1,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Flur",
            "repraesentiertDurch": "Portemonnaie auf der Flur-Kommode oder Ausgeh-Kleidung",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A13",
            "cellRef": "A13",
            "name": "Nachts ganz bewusst den Mond und die Sterne betrachten",
            "mb": 2,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Teleskop am Fenster",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A14",
            "cellRef": "A14",
            "name": "Mit Kindern spielen",
            "mb": 1,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Kinderzimmer",
            "repraesentiertDurch": "Bunte Spielzeug-Eisenbahn oder Plüsch-Einhorn",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A15",
            "cellRef": "A15",
            "name": "Auf einer Bank sitzen.",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Gemütliches Kissen auf der Fensterbank",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A16",
            "cellRef": "A16",
            "name": "10000 Schritte gehen",
            "mb": 2,
            "xp": 50,
            "gold": 0,
            "ap": 0,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Paar Laufschuhe im Vordergrund",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A17",
            "cellRef": "A17",
            "name": "10000 Schritte um 5 Uhr gehen",
            "mb": 5,
            "xp": 100,
            "gold": 0,
            "ap": 3,
            "raum": "Flur",
            "repraesentiertDurch": "Oranger Eulen-Wecker im Flurregal",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A18",
            "cellRef": "A18",
            "name": "Zimmer oder Wohnung aufräumen (30 min)",
            "mb": 1,
            "xp": 50,
            "gold": 0,
            "ap": 0,
            "raum": "Flur",
            "repraesentiertDurch": "Freies braunes Holzbrett auf der Flur-Kommode",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A19",
            "cellRef": "A19",
            "name": "Ein Instrument spielen oder neu lernen (30 min)",
            "mb": 1,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Stage Piano & Synthesizer",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A20",
            "cellRef": "A20",
            "name": "Etwas basteln oder bauen (30 min)",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Kinderzimmer",
            "repraesentiertDurch": "Kleiner Mal- & Basteltisch",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A21",
            "cellRef": "A21",
            "name": "Rechnungen bezahlen oder Formulare richtig ausfüllen und abschicken",
            "mb": -2,
            "xp": 300,
            "gold": 0,
            "ap": 3,
            "raum": "Dashboard",
            "repraesentiertDurch": "Briefstapel & Taschenrechner am Schreibtisch",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A22",
            "cellRef": "A22",
            "name": "Sich mit einem Menschen, den man mag, unterhalten",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Zwei dampfende Teetassen auf dem Couchtisch",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A23",
            "cellRef": "A23",
            "name": "Gemeinsam mit jemandem lachen",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Geöffnetes Fotoalbum auf dem Couchtisch",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A24",
            "cellRef": "A24",
            "name": "Mit jemandem Sex haben",
            "mb": 2,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Kerzen auf der Kommode",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A25",
            "cellRef": "A25",
            "name": "Jemandem sagen, dass man ihm oder ihr dankbar ist oder sie/ihn gern hat",
            "mb": 1,
            "xp": 15,
            "gold": 0,
            "ap": 0,
            "raum": "Flur",
            "repraesentiertDurch": "Erinnerungs-Postkarten & Notizen an der Zimmertür",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A26",
            "cellRef": "A26",
            "name": "Eigene Stärken und Talente bewusst machen... Liste oder Test absolvieren",
            "mb": 1,
            "xp": 15,
            "gold": 0,
            "ap": 0,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Aufgeschlagenes Journal auf dem Bett",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A27",
            "cellRef": "A27",
            "name": "Sich bewusst werden, dass die eigenen Schwächen oder Fehler auch nur menschlich sind.",
            "mb": 1,
            "xp": 15,
            "gold": 0,
            "ap": 0,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Spiegel über dem Waschbecken",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A28",
            "cellRef": "A28",
            "name": "Etwas tun, worauf ich stolz bin (auch wenn es nur eine kleine Sache ist)",
            "mb": 1,
            "xp": 15,
            "gold": 0,
            "ap": 0,
            "raum": "Kinderzimmer",
            "repraesentiertDurch": "Bunte Bücherregale & gerahmte Kinderzeichnung",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A29",
            "cellRef": "A29",
            "name": "Sich sportlich betätigen",
            "mb": 2,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Ausgerollte Yogamatte & Hanteln",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A30",
            "cellRef": "A30",
            "name": "Etwas tun, was man besonders gut kann",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Küche",
            "repraesentiertDurch": "Lieblings-Kaffeetasse neben der Siebträgermaschine",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A31",
            "cellRef": "A31",
            "name": "Etwas probieren, was man noch nicht besonders gut kann",
            "mb": 1,
            "xp": 15,
            "gold": 0,
            "ap": 0,
            "raum": "Flur",
            "repraesentiertDurch": "Unfertiges Puzzle oder Brettspiel-Box im Regal",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A32",
            "cellRef": "A32",
            "name": "Etwas tun, was einem sonst nicht leicht fällt",
            "mb": 1,
            "xp": 300,
            "gold": 0,
            "ap": 1,
            "raum": "Dashboard",
            "repraesentiertDurch": "Klemmbrett mit abgehakter To-Do-Liste an der Korkwand",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A33",
            "cellRef": "A33",
            "name": "Klavier spielen (20 min)",
            "mb": 3,
            "xp": 15,
            "gold": 0,
            "ap": 1,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Stage Piano in der Musikecke",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A34",
            "cellRef": "A34",
            "name": "Kalt duschen",
            "mb": 1,
            "xp": 5,
            "gold": 0,
            "ap": 0,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Regenduschkopf mit blauen Wassertropfen",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A35",
            "cellRef": "A35",
            "name": "Deprexis",
            "mb": 2,
            "xp": 25,
            "gold": 0,
            "ap": 0,
            "raum": "Dashboard",
            "repraesentiertDurch": "Deprexis Online-Therapie am Laptop",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A36",
            "cellRef": "A36",
            "name": "Atemübung durchführen (1 Min)",
            "mb": 5,
            "xp": 50,
            "gold": 0,
            "ap": 0,
            "raum": "Flur",
            "repraesentiertDurch": "Oranger Eulen-Buddy im Regal",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A37",
            "cellRef": "A37",
            "name": "Zentangle (10 min)",
            "mb": 1,
            "xp": 50,
            "gold": 0,
            "ap": 0,
            "raum": "Küche",
            "repraesentiertDurch": "Skizzenblock und schwarzer Fineliner",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A38",
            "cellRef": "A38",
            "name": "Venla",
            "mb": 2,
            "xp": 50,
            "gold": 0,
            "ap": 0,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Pillendose auf der Bad-Ablage",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A39",
            "cellRef": "A39",
            "name": "Mit Pia Rimworld spielen",
            "mb": 2,
            "xp": 125,
            "gold": 0,
            "ap": 0,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Zwei Gamepads am Kallax-Regal",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A40",
            "cellRef": "A40",
            "name": "ADHD Quest programmieren",
            "mb": 1,
            "xp": 500,
            "gold": 0,
            "ap": 1,
            "raum": "Dashboard",
            "repraesentiertDurch": "Offener Laptop & Roboter-Figur auf dem Schreibtisch",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A42",
            "cellRef": "A42",
            "name": "Mittagsspaziergang",
            "mb": 2,
            "xp": 125,
            "gold": 0,
            "ap": 1,
            "raum": "Flur",
            "repraesentiertDurch": "Sonnenbrille & Wohnungsschlüssel auf der Kommode",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A44",
            "cellRef": "A44",
            "name": "Handwerken (Holz)",
            "mb": 3,
            "xp": 500,
            "gold": 0,
            "ap": 1,
            "raum": "Kinderzimmer",
            "repraesentiertDurch": "Holz-Werkzeugkasten mit Japansäge & Stecheisen",
            "zielTabelle": "MB Aktivitaeten"
      },
      {
            "id": "MB_A45",
            "cellRef": "A45",
            "name": "Vibe Coding",
            "mb": 2,
            "xp": 500,
            "gold": 0,
            "ap": 1,
            "raum": "Dashboard",
            "repraesentiertDurch": "Coding-Kopfhörer & beleuchtete mechanische Tastatur",
            "zielTabelle": "MB Aktivitaeten"
      }
],
    aufgaben: [
      {
            "id": "AUF_A2",
            "cellRef": "A2",
            "name": "Ronja zum Kindergarten bringen",
            "mb": 0,
            "xp": 10,
            "gold": 1,
            "ap": 1,
            "raum": "Flur",
            "repraesentiertDurch": "Pinnwand an der Zimmertür",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A3",
            "cellRef": "A3",
            "name": "Ronja vom Kindergarten abholen",
            "mb": 0,
            "xp": 15,
            "gold": 1,
            "ap": 1,
            "raum": "Flur",
            "repraesentiertDurch": "Garderobenhaken mit Ronjas Jacke",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A4",
            "cellRef": "A4",
            "name": "Wäsche waschen",
            "mb": 0,
            "xp": 50,
            "gold": 25,
            "ap": 1,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Waschmaschine & Waschpulver",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A5",
            "cellRef": "A5",
            "name": "Gewaschene Wäsche ausräumen und zum Trockner bringen",
            "mb": 0,
            "xp": 50,
            "gold": 25,
            "ap": 1,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Wäschekorb vor der Waschmaschine",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A6",
            "cellRef": "A6",
            "name": "Trockner ausräumen und Wäsche zusammenlegen",
            "mb": 0,
            "xp": 50,
            "gold": 25,
            "ap": 2,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Wäschetrockner & zusammengelegte Handtücher",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A7",
            "cellRef": "A7",
            "name": "Samstagsputz (Küche)",
            "mb": 0,
            "xp": 100,
            "gold": 50,
            "ap": 2,
            "raum": "Küche",
            "repraesentiertDurch": "Putzmittel-Eimer & Schwamm auf der Arbeitsplatte",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A8",
            "cellRef": "A8",
            "name": "Samstagsputz (Wohnzimmer)",
            "mb": 0,
            "xp": 125,
            "gold": 50,
            "ap": 2,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Staubsauger & Mikrofasertuch",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A9",
            "cellRef": "A9",
            "name": "Samstagsputz (Schlafzimmer)",
            "mb": 0,
            "xp": 150,
            "gold": 50,
            "ap": 2,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Frisch bezogenes Bett & Staubwedel",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A10",
            "cellRef": "A10",
            "name": "Samstagsputz (Bad)",
            "mb": 0,
            "xp": 125,
            "gold": 50,
            "ap": 2,
            "raum": "Badezimmer",
            "repraesentiertDurch": "Badreiniger & Bodenwischer",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A11",
            "cellRef": "A11",
            "name": "Mittagessen vorbereiten",
            "mb": 0,
            "xp": 125,
            "gold": 1,
            "ap": 1,
            "raum": "Küche",
            "repraesentiertDurch": "Großes Schneidebrett mit Kochmesser & Kochtopf",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A12",
            "cellRef": "A12",
            "name": "Einkaufen gehen",
            "mb": 0,
            "xp": 125,
            "gold": 10,
            "ap": 1,
            "raum": "Flur",
            "repraesentiertDurch": "Einkaufstasche an der Flurgarderobe",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A13",
            "cellRef": "A13",
            "name": "Geschirrspüler ausräumen und einräumen",
            "mb": 0,
            "xp": 125,
            "gold": 10,
            "ap": 1,
            "raum": "Küche",
            "repraesentiertDurch": "Geschirrspüler",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A14",
            "cellRef": "A14",
            "name": "Müll rausbringen",
            "mb": 0,
            "xp": 125,
            "gold": 10,
            "ap": 1,
            "raum": "Küche",
            "repraesentiertDurch": "Mülleimer-Trennsystem unter der Spüle",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A15",
            "cellRef": "A15",
            "name": "Wäsche zusammenlegen",
            "mb": 0,
            "xp": 50,
            "gold": 10,
            "ap": 1,
            "raum": "Flur",
            "repraesentiertDurch": "Kommoden-Schubladen ordentlich einräumen",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A16",
            "cellRef": "A16",
            "name": "Ronja ins Bett bringen",
            "mb": 0,
            "xp": 10,
            "gold": 1,
            "ap": 1,
            "raum": "Kinderzimmer",
            "repraesentiertDurch": "Gute-Nacht-Buch auf dem Kinderbett",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A17",
            "cellRef": "A17",
            "name": "Tisch abwischen",
            "mb": 0,
            "xp": 5,
            "gold": 5,
            "ap": 1,
            "raum": "Flur",
            "repraesentiertDurch": "Holzbrett der Kommode komplett frei halten",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A18",
            "cellRef": "A18",
            "name": "Unkraut jähten",
            "mb": 0,
            "xp": 100,
            "gold": 100,
            "ap": 1,
            "raum": "Flur",
            "repraesentiertDurch": "Gartenhandschuhe & Unkrautstecher",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A35",
            "cellRef": "A35",
            "name": "Täglicher Check AfA Bewerbungen",
            "mb": 1,
            "xp": 25,
            "gold": 50,
            "ap": 1,
            "raum": "Dashboard",
            "repraesentiertDurch": "Schreibtisch-Organizer & AfA-Unterlagen",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A36",
            "cellRef": "A36",
            "name": "Tägliche Recherche Jobbörsen (20 min)",
            "mb": 1,
            "xp": 25,
            "gold": 50,
            "ap": 1,
            "raum": "Dashboard",
            "repraesentiertDurch": "Laptop auf dem Schreibtisch mit Jobbörsen-Tabs",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A37",
            "cellRef": "A37",
            "name": "Lernen für ISTQB (Softwaretesting) 30 min",
            "mb": 0,
            "xp": 50,
            "gold": 100,
            "ap": 3,
            "raum": "Dashboard",
            "repraesentiertDurch": "ISTQB-Lehrbuch & Textmarker am Schreibtisch",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A38",
            "cellRef": "A38",
            "name": "Planking (10 min)",
            "mb": 1,
            "xp": 50,
            "gold": 50,
            "ap": 1,
            "raum": "Schlafzimmer",
            "repraesentiertDurch": "Ausgerollte Fitnessmatte auf dem Boden",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A39",
            "cellRef": "A39",
            "name": "Vorbereitung auf Vorstellungsgespräch",
            "mb": 0,
            "xp": 50,
            "gold": 125,
            "ap": 1,
            "raum": "Dashboard",
            "repraesentiertDurch": "Klemmbrett mit Fragen & Notizblock",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A40",
            "cellRef": "A40",
            "name": "Stare at the Wall (10 min)",
            "mb": 2,
            "xp": 125,
            "gold": 100,
            "ap": 1,
            "raum": "Wohnzimmer",
            "repraesentiertDurch": "Leere weiße Wand gegenüber dem Sessel",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A41",
            "cellRef": "A41",
            "name": "Bewerbung geschrieben und abgeschickt",
            "mb": 2,
            "xp": 500,
            "gold": 300,
            "ap": 3,
            "raum": "Dashboard",
            "repraesentiertDurch": "Versandbereite Bewerbungsmappe am Schreibtisch",
            "zielTabelle": "Aufgaben"
      },
      {
            "id": "AUF_A42",
            "cellRef": "A42",
            "name": "Bauprojekt Schlafzimmerempore und Flurebene",
            "mb": 3,
            "xp": 1000,
            "gold": 1000,
            "ap": 2,
            "raum": "Flur",
            "repraesentiertDurch": "Werkzeugkasten mit Bauplan, Zollstock & Akkuschrauber",
            "zielTabelle": "Aufgaben"
      }
]
  };


  // --- TOP-3 HÄUFIGSTE AKTIVITÄTEN AUS DEM QUESTLOG (FÜR DIE 3 PINNWAND-HAFTNOTIZEN) ---
  function getTop3FrequentActivities() {
    // 1. Alle verfügbaren Raum-Objekte (mit Icons/Sprites) + Katalog-Einträge indizieren
    const byName = {};
    const cat = state.sheetCatalog || DEFAULT_SHEET_CATALOG;
    (cat.aufgaben || DEFAULT_SHEET_CATALOG.aufgaben).forEach(a => {
      byName[a.name] = Object.assign({}, a, { icon: "🧹", shortLabel: a.name.split(" ")[0] });
    });
    (cat.mbAktivitaeten || DEFAULT_SHEET_CATALOG.mbAktivitaeten).forEach(m => {
      byName[m.name] = Object.assign({}, m, { icon: "✨", shortLabel: m.name.split(" ")[0] });
    });

    Object.keys(ROOM_OBJECTS).forEach(rKey => {
      (ROOM_OBJECTS[rKey] || []).forEach(ro => {
        if (!ro.isMapDoor && !ro.isShopTrigger && ro.name) {
          const existing = byName[ro.name] || {};
          byName[ro.name] = Object.assign({}, existing, ro, {
            id: ro.id || existing.id,
            icon: ro.icon || existing.icon || "✨",
            iconUrl: ro.iconUrl || existing.iconUrl || "",
            shortLabel: ro.name.replace(/\s*\(.*?\)/g, "").trim()
          });
        }
      });
    });

    // 2. Häufigkeit im Questlog zählen (nur echte Aufgaben & MB-Aktivitäten, keine System/Shop-Einträge)
    const counts = {};
    (state.questlog || []).forEach(entry => {
      const actName = (entry.aktivitaet || "").trim();
      if (!actName || entry.typ === "System" || entry.typ === "Shop") return;
      if (byName[actName]) {
        counts[actName] = (counts[actName] || 0) + 1;
      }
    });

    const sortedNames = Object.keys(counts).sort((a, b) => counts[b] - counts[a]);

    // 3. Sinnvolle Standard-Favoriten als Fallback, falls noch weniger als 3 verschiedene Aktivitäten im Questlog stehen
    const fallbackDefaults = [
      "Geschirrspüler ausräumen und einräumen",
      "Venla",
      "Klavier spielen (20 min)",
      "ADHD Quest programmieren",
      "Tisch abwischen"
    ];
    fallbackDefaults.forEach(fb => {
      if (sortedNames.length < 3 && byName[fb] && !sortedNames.includes(fb)) {
        sortedNames.push(fb);
      }
    });

    // 4. Die 3 Haftnotiz-Positionen auf der Kork-Pinnwand im Dashboard (inkl. evtl. PC-Entwicklermodus-Overrides)
    const customMap = (state && state.customObjectLayout) || {};
    const postitSlots = FACTORY_POSTIT_SLOTS.map(s => {
      const ov = customMap[s.id] || {};
      return Object.assign({}, s, ov);
    });

    return postitSlots.map((slot, idx) => {
      const name = sortedNames[idx] || fallbackDefaults[idx];
      const item = byName[name] || {
        id: "TOP3_" + (idx + 1),
        name: name,
        zielTabelle: "Aufgaben",
        xp: 50, gold: 10, mb: 1, ap: 1,
        icon: "⭐",
        shortLabel: name
      };
      return Object.assign({}, item, slot, {
        countInLog: counts[name] || 0
      });
    });
  }

  function getRoomCatalog(roomName) {
    const cat = state.sheetCatalog || DEFAULT_SHEET_CATALOG;
    const mbList = (cat.mbAktivitaeten && cat.mbAktivitaeten.length ? cat.mbAktivitaeten : DEFAULT_SHEET_CATALOG.mbAktivitaeten)
      .filter(x => !roomName || roomName === "Alle" || x.raum === roomName);
    const aufList = (cat.aufgaben && cat.aufgaben.length ? cat.aufgaben : DEFAULT_SHEET_CATALOG.aufgaben)
      .filter(x => !roomName || roomName === "Alle" || x.raum === roomName);
    return { mbAktivitaeten: mbList, aufgaben: aufList };
  }

  // 6. Tabellenblatt "Charakterbogen" (Exakt deine aktuellen Live-Werte aus dem Sheet!)
  const defaultState = {
    version: APP_VERSION,
    character: {
      mb: 95,            // B3: Mentale Belastbarkeit (MB) = 95 (Live-Sheet)
      maxMb: 100,
      hp: 54,            // B4: Lebenspunkte (HP) = 54
      maxHp: 54,
      level: 25,         // B6: Level = 25
      xp: 59005,         // B8: Gesamt-XP = 59005
      levelProgressText: "1405 / 4900 XP", // C8
      gold: 9424,        // B10: Gold = 9424
      ap: 7,             // D10: Aktionspunkte = 7
      maxAp: 10,
      aktuelleQuest: "ISTQB Foundation Level", // C14
      streak: 5
    },
    settings: {
      currentRoom: "Dashboard",
      liveSheetSync: true,
      uiFrame: "frame_1_wood_gold",
      colorTheme: "gold",
      showRoomBadgeOnFrame: true,
      miniStatPillCollapsed: false,
      showBottomRoomDock: true,
      timeOfDayMode: "auto",
      pinnedShopGoalId: "Effektpedal kaufen"
    },
    roomDirtLevels: {
      "Flur": 1,
      "Wohnzimmer": 1,
      "Küche": 1,
      "Schlafzimmer": 1,
      "Badezimmer": 1
    },
    customObjectLayout: {},
    luggageChestItems: [],
    dailyMbSnapshots: {},
    completedToday: {},
    questlog: [
      { datum: "01.11.2026", uhrzeit: "20:00", aktivitaet: "Tabellen-Datenstruktur geladen (Level 25 | 9424 Gold | 94% MB)", typ: "System", xp: 0, mb: 0, gold: 0, ap: 0 }
    ]
  };

  let state = loadState();
  applyCustomLayoutToObjects();

  function applyCustomLayoutToObjects() {
    const custom = (state && state.customObjectLayout) || {};
    Object.keys(ROOM_OBJECTS).forEach(rKey => {
      const origList = FACTORY_ROOM_OBJECTS[rKey] || [];
      ROOM_OBJECTS[rKey].forEach((obj, idx) => {
        const baseObj = origList[idx] || obj;
        const ov = custom[obj.id];
        if (ov) {
          ["leftPct", "topPct", "widthPct", "heightPct", "xPct", "yPct", "zIndex", "rotDeg"].forEach(k => {
            if (ov[k] !== undefined) obj[k] = ov[k];
          });
        } else {
          ["leftPct", "topPct", "widthPct", "heightPct", "xPct", "yPct", "zIndex", "rotDeg"].forEach(k => {
            if (baseObj[k] !== undefined) obj[k] = baseObj[k];
            else delete obj[k];
          });
        }
      });
    });

    Object.keys(ASSETS.doorCleaningCoords).forEach(rKey => {
      const baseCfg = FACTORY_DOOR_CLEANING[rKey];
      const cleanId = `CLEAN_DYNAMIC_${rKey}`;
      const ov = custom[cleanId];
      if (ov) {
        ["leftPct", "topPct", "widthPct", "heightPct", "zIndex", "rotDeg"].forEach(k => {
          if (ov[k] !== undefined) ASSETS.doorCleaningCoords[rKey][k] = ov[k];
        });
      } else if (baseCfg) {
        Object.assign(ASSETS.doorCleaningCoords[rKey], JSON.parse(JSON.stringify(baseCfg)));
      }
    });
  }

  function updateObjectLayout(objId, props) {
    if (!state.customObjectLayout) state.customObjectLayout = {};
    state.customObjectLayout[objId] = Object.assign({}, state.customObjectLayout[objId] || {}, props);
    applyCustomLayoutToObjects();
    saveState();
  }

  function resetObjectLayout(objId) {
    if (state.customObjectLayout && state.customObjectLayout[objId]) {
      delete state.customObjectLayout[objId];
      applyCustomLayoutToObjects();
      saveState();
    }
  }

  function resetRoomLayout(roomName) {
    if (!state.customObjectLayout) return;
    (ROOM_OBJECTS[roomName] || []).forEach(o => {
      delete state.customObjectLayout[o.id];
    });
    delete state.customObjectLayout[`CLEAN_DYNAMIC_${roomName}`];
    if (roomName === "Dashboard") {
      ["POSTIT_SLOT_1", "POSTIT_SLOT_2", "POSTIT_SLOT_3"].forEach(pid => delete state.customObjectLayout[pid]);
    }
    applyCustomLayoutToObjects();
    saveState();
  }

  function exportRoomLayoutCode(roomName) {
    const rName = roomName || state.settings.currentRoom || "Dashboard";
    const objs = ROOM_OBJECTS[rName] || [];
    const payload = {
      room: rName,
      updatedAt: new Date().toISOString(),
      objects: objs.map(o => ({
        id: o.id,
        name: o.name,
        leftPct: o.leftPct,
        topPct: o.topPct,
        widthPct: o.widthPct,
        heightPct: o.heightPct,
        zIndex: o.zIndex || 12,
        rotDeg: o.rotDeg || 0
      }))
    };
    if (rName === "Dashboard") {
      payload.postitSlots = getTop3FrequentActivities().map(p => ({
        slotId: `POSTIT_SLOT_${p.slotNr}`,
        leftPct: p.leftPct,
        topPct: p.topPct,
        widthPct: p.widthPct,
        heightPct: p.heightPct,
        rotDeg: p.rotDeg || 0,
        zIndex: p.zIndex || 22
      }));
    }
    if (ASSETS.doorCleaningCoords[rName]) {
      payload.doorCleaning = ASSETS.doorCleaningCoords[rName];
    }
    payload.luggageChestItems = getLuggageChestItems();
    return JSON.stringify(payload, null, 2);
  }

  // --- SCHEIBENWELT-TRUHE ("THE LUGGAGE" / INTELLIGENTES BIRNBAUMHOLZ) FÜR DEN DEV-MODUS (v0.64) ---
  function getLuggageChestItems() {
    if (!Array.isArray(state.luggageChestItems)) {
      state.luggageChestItems = [];
    }
    return state.luggageChestItems;
  }

  function isObjectInLuggage(objId) {
    return getLuggageChestItems().includes(objId);
  }

  function findObjectByIdAcrossRooms(objId) {
    for (const rKey of Object.keys(ROOM_OBJECTS)) {
      const found = (ROOM_OBJECTS[rKey] || []).find(o => o.id === objId);
      if (found) return found;
    }
    return null;
  }

  function getLuggageChestObjectsDetailed() {
    return getLuggageChestItems().map(id => {
      const obj = findObjectByIdAcrossRooms(id);
      if (obj) return obj;
      return { id, name: id, raum: "Unbekannt", icon: "📦" };
    });
  }

  function storeObjectInLuggage(objId) {
    if (!objId) return { ok: false };
    // Post-its oder dynamische Tür-Besen nicht in die Truhe sperren, nur echte Raum-Objekte
    const obj = findObjectByIdAcrossRooms(objId);
    if (!obj) return { ok: false, msg: "Nur feste Raum-Gegenstände können in die Truhe gepackt werden." };
    const list = getLuggageChestItems();
    if (!list.includes(objId)) {
      list.push(objId);
      saveState();
    }
    return { ok: true, obj };
  }

  function restoreObjectFromLuggage(objId, targetRoom) {
    const list = getLuggageChestItems();
    const idx = list.indexOf(objId);
    if (idx === -1) return { ok: false };
    list.splice(idx, 1);
    const obj = findObjectByIdAcrossRooms(objId);
    // Optional: Falls ein Zielraum übergeben wird und das Objekt im aktuellen Raum platziert werden soll
    if (obj && targetRoom && obj.raum !== targetRoom) {
      // Verschiebe Objekt in den gewünschten Raum, falls es dort abgelegt wird
      const oldRoomList = ROOM_OBJECTS[obj.raum] || [];
      const oldIdx = oldRoomList.findIndex(o => o.id === objId);
      if (oldIdx !== -1) {
        oldRoomList.splice(oldIdx, 1);
      }
      obj.raum = targetRoom;
      if (!ROOM_OBJECTS[targetRoom]) ROOM_OBJECTS[targetRoom] = [];
      ROOM_OBJECTS[targetRoom].push(obj);
    }
    saveState();
    return { ok: true, obj };
  }

  function emptyLuggageChest() {
    state.luggageChestItems = [];
    // Stelle auch Raum-Zuordnungen aus FACTORY_ROOM_OBJECTS wieder her
    Object.keys(FACTORY_ROOM_OBJECTS).forEach(rKey => {
      ROOM_OBJECTS[rKey] = JSON.parse(JSON.stringify(FACTORY_ROOM_OBJECTS[rKey]));
    });
    applyCustomLayoutToObjects();
    saveState();
  }



  // --- 90er LUCASARTS POINT-&-CLICK OBJEKTKOMMENTARE ("Schau an..." / v0.56) ---
  const LUCASARTS_QUIPS = {
    // 1. FLUR
    "FLU_001_01": "„Eine horizontale Holzfläche im Flur! Laut dem Ersten Gesetz der ADHS-Thermodynamik zieht sie losen Kram magisch an – außer ich wische sofort drüber.“",
    "FLU_002_01": "„Mein Brettspiel- und Witzebuch-Archiv. Falls mich je ein Pirat zum Beleidigungs-Fechten herausfordert, bin ich bestens präpariert.“",
    "FLU_003_01": "„5:00 Uhr morgens?! Selbst die Holz-Eule guckt mich an, als hätte ich den Verstand verloren. Aber 100 XP und +5 MB lügen nicht.“",
    "FLU_004_01": "„Grün-weiße Schubladen. Dahinter verbirgt sich das gefürchtete Textil-Tetris auf Schwierigkeitsgrad ‚Meister‘.“",
    "FLU_005_01": "„Die Familien-Kommandozentrale. Dagegen wirkt das Questlog in World of Warcraft wie ein kleiner Einkaufszettel.“",
    "FLU_006_01": "„Schlüssel, Portemonnaie, Sonnenbrille – alle am selben Ort! Ein seltenes Phänomen, das Wissenschaftler noch nicht vollständig erklären können.“",
    "FLU_007_01": "„Ronjas Jacke und der Einkaufsbeutel. Zeit für die tägliche Eskort-Quest – zum Glück mit deutlich besserer KI als in alten RPGs.“",
    "FLU_008_01": "„KVH-Balken, Zollstock und Akkuschrauber. Wenn Guybrush Threepwood ein 100 cm hohes Podest bauen müsste, würde er genau hier anfangen.“",

    // 2. DASHBOARD
    "DASH_001_PINNWAND": "„Plan A, Budget und die große Übersicht. Ich liebe es, wenn ein Plan funktioniert… oder zumindest bunt angepinnt ist.“",
    "DASH_002_GOALS": "„Meine GOALS-Checkliste. Wer braucht schon Charisma-Buff-Food, wenn man gut vorbereitet ins Gespräch geht?“",
    "DASH_003_LAMPE": "„Kopfhörer auf, Lampe an, Welt aus. Zeit, im Hyperfokus Code-Magie zu wirken, bis die Tasten glühen.“",
    "DASH_004_ORGANIZER": "„Der tägliche Check der Bewerbungs-Quests. Bürokratie ist zwar kein geschmeidiger Bosskampf, droppt aber verlässlich 50 Gold.“",
    "DASH_005_RECHNER": "„Papierkram und Rechnungen… kostet satte 2 Punkte Mentale Batterie, aber 300 XP sind ein verdammt überzeugendes Argument.“",
    "DASH_007_ROBOTER": "„Ich programmiere in einer App eine Quest darüber, wie ich diese App programmiere. Wenn das kein Meta-Gaming auf LucasArts-Niveau ist!“",
    "DASH_008_NOTIZBUCH": "„20 Minuten gezielte Recherche im Netz – natürlich mit der eisernen Disziplin, nicht nach drei Klicks im Wikipedia-Kaninchenbau über mittelalterliche Belagerungswaffen zu landen.“",
    "DASH_009_ISTQB": "„Boundary Value Analysis und Equivalence Partitioning… klingt wie ein Zauberspruch aus Dalaran, ist aber reines ISTQB-Wissen.“",
    "DASH_010_KOFFER": "„Eine fertig abgeschickte Bewerbung! Das Gefühl beim Klick auf ‚Senden‘ schlägt jeden epischen Raid-Drop.“",

    // 3. WOHNZIMMER
    "WOH_001_STAGEPIANO": "„88 Tasten reines Dopamin. 20 Minuten spielen regeneriert mehr Mentale Batterie als jeder Heiltrank.“",
    "WOH_002_SYNTH": "„So viele Regler, Kabel und blinkende Knöpfe… wenn ich den Filter-Cutoff noch weiter aufdrehe, öffnet sich ein Zeitportal ins Jahr 1993.“",
    "WOH_003_UKULELEN": "„Vier Saiten, gute Laune und null Ladezeit. Perfekt für eine kleine musikalische Nebenquest zwischendurch.“",
    "WOH_004_MONITORBOXEN": "„Studio-Monitore mit kristallklarem Sound. Fast so schön wie ein originaler Soundblaster-16-MIDI-Soundtrack.“",
    "WOH_005_FOTOALBUM": "„Ein analoges Bilder-Speichermedium ganz ohne Cloud-Abo. Ein Blick hinein und die Laune steigt sofort.“",
    "WOH_006_SOFAKISSEN": "„Ein Ort der Stille und der weichen Kissen. Ideal für einen kurzen taktischen Ruhestein-Moment.“",
    "WOH_007_TEETASSEN": "„Zwei dampfende Tassen und ein gutes Gespräch. Besser als jede Taverne auf Melee Island.“",
    "WOH_008_GAMEPADS": "„Zwei Controller bereit für Rimworld mit Pia. Hoffentlich überlebt unsere Kolonie diesmal länger als bis zum nächsten verrückten Eichhörnchen-Angriff.“",
    "WOH_009_FERNSEHER": "„Ein guter Film auf dem Bildschirm. Keine täglichen Quests, kein Grind – einfach nur zurücklehnen und genießen.“",
    "WOH_010_WANDFOKUS": "„10 Minuten lang einfach nur die Wand anstarren. Für Außenstehende rätselhaft, für ein ADHS-Gehirn ein kompletter System-Neustart (+125 XP!).“",
    "WOH_AUF_001": "„Der Staubsauger – der natürliche Feind der Wollmäuse. Mit dem Samstagsputz glänzt das Wohnzimmer wieder wie neu.“",

    // 4. KÜCHE
    "KUE_001_01": "„Der Endgegner der Küche. Man räumt ihn aus, dreht sich einmal um, und irgendjemand hat schon wieder drei Löffel und eine Tasse gespawnt.“",
    "KUE_002_01": "„Einmal kurz über die karierte Tischdecke wischen. Geht schneller als gedacht und bringt sofortige visuelle Ruhe.“",
    "KUE_003_01": "„Scharfes Messer, Holzbrett und Kupfertopf. Alchemie auf Großmeister-Stufe – nur dass man das Ergebnis essen kann.“",
    "KUE_AUF_004": "„Eine kurze Expedition vor die Tür zu den Mülltonnen. Gibt 125 XP und verhindert, dass der Eimer eigenes Bewusstsein entwickelt.“",
    "KUE_MB_001": "„Die Siebträgermaschine glänzt. Zeit, feinstes schwarzes Elixier der Wachsamkeit zu brauen.“",
    "KUE_MB_002": "„Fineliner und Papier. 10 Minuten Zentangle-Striche ziehen und das Gedankenkarussell schaltet brav in den Leerlauf.“",

    // 5. SCHLAFZIMMER
    "SCH_MB_001": "„Massageöl auf dem Sideboard. Der effektivste bekannte Debuff-Entferner gegen verspannte Schultern.“",
    "SCH_MB_002": "„Gemütliche Kissen in Rostorange und Senfgelb. Ein sicherer Hafen fernab aller To-Do-Listen.“",
    "SCH_MB_003": "„Ein echtes Messing-Teleskop am Fenster. Wenn man nachts lange genug in den Sternenhimmel schaut, relativiert sich jedes Alltagsproblem von selbst.“",
    "SCH_MB_004": "„Die ausgerollte Matte schaut mich erwartungsvoll an. Mein Körper sagt ‚Sofa‘, aber die +2 MB und +25 XP sagen ‚Los geht’s!‘.“",
    "SCH_MB_005": "„Meine Laufschuhe stehen bereit. 10.000 Schritte sind im Grunde auch nur eine ausgedehnte Erkundungs-Quest an der frischen Luft.“",
    "SCH_MB_006": "„Das aufgeschlagene Journal am Nachttisch. Schwarz auf weiß festgehalten, was heute gut lief – ein echtes Schild gegen Selbstzweifel.“",
    "SCH_MB_007": "„Warmes Kerzenlicht und Zeit zu zweit. Definitiv die schönste Koop-Quest im gesamten Spiel.“",
    "SCH_AUF_001": "„Frische Bettwäsche und Staubwedel. Nichts schläft sich besser als in einem frisch geputzten Schlafzimmer.“",

    // 6. BADEZIMMER
    "BAD_MB_001": "„Die gepackte Badetasche wartet schon. Ein paar Bahnen ziehen wirkt auf das Gehirn wie ein kompletter Cache-Clear (+5 MB!).“",
    "BAD_MB_002": "„Kalt duschen! Die ersten fünf Sekunden fühlen sich an wie ein Frostblitz auf Stufe 80 – danach ist man hellwach.“",
    "BAD_MB_003": "„Der tägliche Buff für die Neurotransmitter. Klein, unspektakulär, aber hält die Basis-Stats verlässlich im grünen Bereich.“",
    "BAD_MB_004": "„Ein kurzer Blick in den Spiegel: Fehler passieren jedem Abenteurer mal. Durchatmen, Krone bzw. Schiebermütze richten, weitergehen.“",
    "BAD_AUF_001": "„Der Wäscheberg vor der Maschine wächst schneller als ein Respawn im Startgebiet. Hinein damit!“",
    "BAD_AUF_002": "„Badreiniger und Abzieher. Nach 15 Minuten glänzen die Armaturen wieder wie poliertes Zwergengold.“",
    "BAD_AUF_003": "„Warme Handtücher direkt aus dem Trockner zusammenlegen. Fast schon meditativ – solange keine einzelne Socke verschwindet.“",

    // 7. KINDERZIMMER
    "KIN_MB_001": "„Die Holzeisenbahn dreht ihre Runden um den Bauklotz-Turm. Der Fahrplan ist zwar chaotisch, aber die Stimmung beim Mitspielen erstklassig.“",
    "KIN_MB_002": "„Buntstifte, Schere und Papier. Hier entstehen Meisterwerke, die jeden Louvre-Kurator neidisch machen würden.“",
    "KIN_MB_003": "„Japansäge, Stecheisen und Holz. Wenn hier der Marke ‚Paddywood Est. 1979‘ gefertigt wird, gibt das satte 500 XP!“",
    "KIN_MB_004": "„Das gerahmte ‚Gelato Girl‘-Poster an der Wand. Eine schöne Erinnerung daran, auch auf die kleinen Erfolge stolz zu sein.“",
    "KIN_MB_005": "„Das rote Korg-Minipiano. Klein, aber oho – Frühförderung für zukünftige Synthesizer-Legenden.“",
    "KIN_MB_006": "„Ein flauschiges Regenbogen-Einhorn. Schaut ungefähr so entspannt drein, wie ich mich nach einem erledigten Quest-Tag fühle.“",
    "KIN_MB_007": "„Die weißen Bücherleisten voller Geschichten. Zusammen vorlesen und einfach dankbar für den Moment sein.“",
    "KIN_AUF_001": "„Das aufgeschlagene Gute-Nacht-Buch. Die abendliche Hauptquest, bevor im Kinderzimmer endgültig Ruhe einkehrt.“",
    "KIN_AUF_002": "„Die bunte Spielzeugkiste. Mal sehen, ob wir die Bauklötze heute gemeinsam gebändigt bekommen.“",

    // 8. DYNAMISCHE PUTZ-SPRITES AN DER TÜR (STUFEN 1 BIS 3)
    "CLEAN_STAGE_1": "„Ein einzelner Besen lehnt an der Tür. Noch ist es nur ein winziges bisschen Unordnung – wenn ich JETZT fege, kassiere ich den doppelten Frühstart-Bonus (x2.0)!“",
    "CLEAN_STAGE_2": "„Besen und Kehrblech stehen bereit. Die Unordnung breitet sich langsam aus… aber für den x1.7-Multiplikator lohnt sich der Einsatz noch richtig!“",
    "CLEAN_STAGE_3": "„Hier hilft kein Besen mehr, jetzt muss schweres Gerät ran! Der Staubsauger wartet schon auf seinen Einsatz (Bonus x1.4).“"
  };

  // --- OBJEKT-ABSCHLUSS-ANIMATIONEN IN DER GROSSANSICHT (HERO-STAGE, MAX. 4 SEK.) (v0.62) ---
  // Jedes Objekt erhält eine maßgeschneiderte Choreografie (CSS-Bewegung + schwebende Effekt-Sprites/Partikel + Banner)
  const OBJECT_STAGE_ANIMATIONS = {
    // === WOHNZIMMER (11 OBJEKTE + DYNAMISCHE PUTZ-STUFEN) ===
    "WOH_001_STAGEPIANO": {
      motionClass: "stage-anim-piano-groove",
      auraColor: "rgba(255, 146, 43, 0.55)",
      bannerText: "🎹 88 Tasten im vollen Groove!",
      particles: ["🎵", "🎶", "🎼", "✨", "🎹", "🎵", "🎶", "✨"],
      trajectory: "float-up-notes"
    },
    "WOH_002_SYNTH": {
      motionClass: "stage-anim-synth-pulse",
      auraColor: "rgba(56, 189, 248, 0.65)",
      bannerText: "🎛️ Filter-Sweep & 90s Synth-Vibes!",
      particles: ["⚡", "🎛️", "🔊", "✨", "🎶", "💫", "⚡", "🔊"],
      trajectory: "radial-synth-waves"
    },
    "WOH_003_UKULELEN": {
      motionClass: "stage-anim-ukulele-strum",
      auraColor: "rgba(250, 204, 21, 0.6)",
      bannerText: "🎸 Aloha-Strumming & gute Laune!",
      particles: ["🎵", "🌺", "🎶", "☀️", "✨", "🎸", "🎵", "🌺"],
      trajectory: "strum-burst"
    },
    "WOH_004_MONITORBOXEN": {
      motionClass: "stage-anim-speaker-bass",
      auraColor: "rgba(168, 85, 247, 0.55)",
      bannerText: "🎧 Kristallklarer Studio-Sound!",
      particles: ["🔊", "🎵", "〰️", "🎶", "✨", "🎧", "🔊", "🎵"],
      trajectory: "sonic-rings"
    },
    "WOH_005_FOTOALBUM": {
      motionClass: "stage-anim-album-flip",
      auraColor: "rgba(244, 114, 182, 0.55)",
      bannerText: "📗 Herzhaft gelacht & Erinnerungen getankt!",
      particles: ["😄", "❤️", "📸", "✨", "😂", "💛", "📸", "✨"],
      trajectory: "warm-hearts"
    },
    "WOH_006_SOFAKISSEN": {
      motionClass: "stage-anim-pillow-cozy",
      auraColor: "rgba(74, 222, 128, 0.5)",
      bannerText: "🛋️ Tiefenentspannt durchgeatmet!",
      particles: ["🌿", "☁️", "✨", "😌", "💤", "🍃", "☁️", "✨"],
      trajectory: "zen-feathers"
    },
    "WOH_007_TEETASSEN": {
      motionClass: "stage-anim-tea-clink",
      auraColor: "rgba(251, 191, 36, 0.58)",
      bannerText: "☕ Wärmendes Gespräch bei heißem Tee!",
      particles: ["♨️", "💬", "❤️", "✨", "🍵", "♨️", "💛", "💬"],
      trajectory: "rising-steam"
    },
    "WOH_008_GAMEPADS": {
      motionClass: "stage-anim-gamepad-rumble",
      auraColor: "rgba(59, 130, 246, 0.65)",
      bannerText: "🎮 Koop-Session mit Pia: Kolonie gerettet!",
      particles: ["🎮", "💥", "⭐", "🏆", "⚡", "👾", "🚀", "⭐"],
      trajectory: "arcade-combo"
    },
    "WOH_009_FERNSEHER": {
      motionClass: "stage-anim-tv-cinema",
      auraColor: "rgba(99, 102, 241, 0.6)",
      bannerText: "🎬 Großes Kino & gemütlicher Filmabend!",
      particles: ["🍿", "🎬", "⭐", "🎞️", "✨", "🍿", "🎥", "⭐"],
      trajectory: "cinema-popcorn"
    },
    "WOH_010_WANDFOKUS": {
      motionClass: "stage-anim-wall-zen",
      auraColor: "rgba(45, 212, 191, 0.58)",
      bannerText: "🕯️ 10 Min. Fokus-Stille: Kopf-Cache geleert!",
      particles: ["🧘", "✨", "🕯️", "💫", "🧠", "✨", "🕯️", "💫"],
      trajectory: "zen-halo"
    },
    "WOH_AUF_001": {
      motionClass: "stage-anim-vacuum-sweep",
      auraColor: "rgba(34, 197, 94, 0.6)",
      bannerText: "🧹 Wohnzimmer-Samstagsputz: Alles blitzt!",
      particles: ["✨", "🫧", "🧹", "🌟", "💨", "✨", "🫧", "🌟"],
      trajectory: "clean-sweep-sparkles"
    },

    // === KINDERZIMMER (9 OBJEKTE) (v0.63) ===
    "KIN_MB_001": {
      motionClass: "stage-anim-train-chug",
      auraColor: "rgba(239, 68, 68, 0.55)",
      bannerText: "🚂 Tschu-Tschu! Volldampf auf dem Spielteppich!",
      particles: ["🚂", "💨", "🚃", "🌟", "🎲", "💨", "🧸", "✨"],
      trajectory: "float-up-notes"
    },
    "KIN_MB_002": {
      motionClass: "stage-anim-craft-scribble",
      auraColor: "rgba(244, 114, 182, 0.6)",
      bannerText: "🎨 Buntes Meisterwerk am Basteltisch!",
      particles: ["🎨", "🖍️", "✂️", "🌈", "⭐", "🖌️", "✨", "🌈"],
      trajectory: "radial-synth-waves"
    },
    "KIN_MB_003": {
      motionClass: "stage-anim-woodwork-craft",
      auraColor: "rgba(217, 119, 6, 0.65)",
      bannerText: "🪚 Paddywood Est. 1979: Feinste Handwerkskunst!",
      particles: ["🪚", "🔨", "🪵", "✨", "📐", "🔥", "🏆", "✨"],
      trajectory: "arcade-combo"
    },
    "KIN_MB_004": {
      motionClass: "stage-anim-poster-pride",
      auraColor: "rgba(250, 204, 21, 0.65)",
      bannerText: "🌟 Gelato Girl glänzt: Stolz auf jeden Schritt!",
      particles: ["🌟", "🍦", "🌸", "✨", "💛", "👑", "🌟", "✨"],
      trajectory: "warm-hearts"
    },
    "KIN_MB_005": {
      motionClass: "stage-anim-korg-jam",
      auraColor: "rgba(239, 68, 68, 0.62)",
      bannerText: "🎹 Rotes Korg-Minipiano: Frühförderungs-Jam!",
      particles: ["🎹", "🎵", "🎶", "🔴", "✨", "🎼", "🎵", "🎶"],
      trajectory: "float-up-notes"
    },
    "KIN_MB_006": {
      motionClass: "stage-anim-unicorn-magic",
      auraColor: "rgba(192, 132, 252, 0.65)",
      bannerText: "🦄 Regenbogen-Einhorn-Magie & Gekicher!",
      particles: ["🦄", "🌈", "💖", "✨", "😂", "⭐", "🌈", "💖"],
      trajectory: "warm-hearts"
    },
    "KIN_MB_007": {
      motionClass: "stage-anim-bookshelf-gratitude",
      auraColor: "rgba(56, 189, 248, 0.55)",
      bannerText: "📚 Vorlese-Zeit & warme Dankbarkeit!",
      particles: ["📚", "💛", "📖", "✨", "🥰", "🌟", "💛", "✨"],
      trajectory: "zen-feathers"
    },
    "KIN_AUF_001": {
      motionClass: "stage-anim-bedtime-lullaby",
      auraColor: "rgba(129, 140, 248, 0.62)",
      bannerText: "📖 Gute-Nacht-Geschichte: Schlaf gut, kleine Ronja!",
      particles: ["🌙", "⭐", "💤", "✨", "📖", "🧸", "🌙", "💤"],
      trajectory: "zen-feathers"
    },
    "KIN_AUF_002": {
      motionClass: "stage-anim-toybox-tidy",
      auraColor: "rgba(34, 197, 94, 0.6)",
      bannerText: "🧸 Spielzeugkiste gebändigt: Alles hüpft rein!",
      particles: ["🧸", "🧱", "✨", "🎉", "🌟", "🎲", "🫧", "✨"],
      trajectory: "arcade-combo"
    },

    // === DASHBOARD / ARBEITSZIMMER (9 OBJEKTE) (v0.65) ===
    "DASH_001_PINNWAND": {
      motionClass: "stage-anim-dash-pinnwand",
      auraColor: "rgba(234, 88, 12, 0.62)",
      bannerText: "📋 Kork-Pinnwand: Hürde gemeistert & abgehakt!",
      particles: ["📌", "✅", "📋", "✨", "🏆", "⭐", "📌", "✅"],
      trajectory: "arcade-combo"
    },
    "DASH_002_GOALS": {
      motionClass: "stage-anim-dash-goals",
      auraColor: "rgba(16, 185, 129, 0.62)",
      bannerText: "🎯 Volltreffer! Top vorbereitet ins Gespräch!",
      particles: ["🎯", "🏹", "🌟", "💼", "✨", "📈", "🎯", "🏆"],
      trajectory: "radial-synth-waves"
    },
    "DASH_003_LAMPE": {
      motionClass: "stage-anim-dash-vibecoding",
      auraColor: "rgba(56, 189, 248, 0.68)",
      bannerText: "💡 Vibe Coding: Hyperfokus-Licht & Code-Magie!",
      particles: ["💡", "⚡", "💻", "🎧", "✨", "🚀", "🔥", "⚡"],
      trajectory: "radial-synth-waves"
    },
    "DASH_004_ORGANIZER": {
      motionClass: "stage-anim-dash-organizer",
      auraColor: "rgba(245, 158, 11, 0.6)",
      bannerText: "✒️ Täglicher AfA-Check: Sauber abgeheftet!",
      particles: ["✒️", "📑", "🪙", "✅", "✨", "📂", "✒️", "✅"],
      trajectory: "float-up-notes"
    },
    "DASH_005_RECHNER": {
      motionClass: "stage-anim-dash-calculator",
      auraColor: "rgba(34, 197, 94, 0.65)",
      bannerText: "🧮 Papierkram-Endgegner besiegt (+300 XP)!",
      particles: ["🧮", "💶", "📨", "✅", "✨", "🎉", "🧾", "🏆"],
      trajectory: "arcade-combo"
    },
    "DASH_007_ROBOTER": {
      motionClass: "stage-anim-dash-robot",
      auraColor: "rgba(168, 85, 247, 0.68)",
      bannerText: "🤖 Meta-Quest: ADHD Quest weiterentwickelt!",
      particles: ["🤖", "⚙️", "💻", "⚡", "✨", "🕹️", "🚀", "🌟"],
      trajectory: "arcade-combo"
    },
    "DASH_008_NOTIZBUCH": {
      motionClass: "stage-anim-dash-notebook",
      auraColor: "rgba(14, 165, 233, 0.6)",
      bannerText: "📖 20 Min. Fokus-Recherche: Voller Überblick!",
      particles: ["📖", "🔍", "💡", "✨", "📝", "🎯", "🔍", "✨"],
      trajectory: "zen-feathers"
    },
    "DASH_009_ISTQB": {
      motionClass: "stage-anim-dash-istqb",
      auraColor: "rgba(99, 102, 241, 0.65)",
      bannerText: "📚 ISTQB-Wissen sitzt: 0 Bugs, 100% Coverage!",
      particles: ["📚", "🎓", "🐞", "✅", "🧠", "✨", "🔖", "🏆"],
      trajectory: "float-up-notes"
    },
    "DASH_010_KOFFER": {
      motionClass: "stage-anim-dash-suitcase",
      auraColor: "rgba(250, 204, 21, 0.7)",
      bannerText: "🧳 Bewerbung abgeschickt! Epischer Meilenstein!",
      particles: ["🧳", "🚀", "✉️", "🪙", "🎉", "🏆", "🌟", "✨"],
      trajectory: "arcade-combo"
    },

    // === KÜCHE (6 OBJEKTE) (v0.66) ===
    "KUE_001_01": {
      motionClass: "stage-anim-kue-dishwasher",
      auraColor: "rgba(56, 189, 248, 0.65)",
      bannerText: "🍽️ Geschirrspüler-Endgegner besiegt: Alles glänzt!",
      particles: ["🍽️", "🫧", "✨", "🥂", "💧", "🌟", "🫧", "✨"],
      trajectory: "rising-steam"
    },
    "KUE_002_01": {
      motionClass: "stage-anim-kue-tablewipe",
      auraColor: "rgba(34, 197, 94, 0.62)",
      bannerText: "🧽 Küchentisch blitzblank: Freie Sicht & Ruhe!",
      particles: ["🧽", "✨", "🍎", "🫧", "🌟", "🍋", "✨", "🫧"],
      trajectory: "clean-sweep-sparkles"
    },
    "KUE_003_01": {
      motionClass: "stage-anim-kue-cooking",
      auraColor: "rgba(249, 115, 22, 0.65)",
      bannerText: "🍳 Meister-Alchemie am Herd: Mittagessen steht!",
      particles: ["🍳", "🔪", "🥕", "♨️", "🥘", "🌿", "✨", "♨️"],
      trajectory: "arcade-combo"
    },
    "KUE_AUF_004": {
      motionClass: "stage-anim-kue-trash",
      auraColor: "rgba(16, 185, 129, 0.62)",
      bannerText: "🗑️ Müll-Expedition erledigt (+125 XP)!",
      particles: ["🗑️", "♻️", "✨", "💨", "🍃", "🪙", "🏆", "✨"],
      trajectory: "arcade-combo"
    },
    "KUE_MB_001": {
      motionClass: "stage-anim-kue-espresso",
      auraColor: "rgba(217, 119, 6, 0.68)",
      bannerText: "☕ Siebträger-Gold: Schwarzes Elixier gebraut!",
      particles: ["☕", "♨️", "🫘", "✨", "🤎", "⚡", "♨️", "✨"],
      trajectory: "rising-steam"
    },
    "KUE_MB_002": {
      motionClass: "stage-anim-kue-zentangle",
      auraColor: "rgba(168, 85, 247, 0.6)",
      bannerText: "✒️ 10 Min. Zentangle-Flow: Kopf im Ruhemodus!",
      particles: ["✒️", "🌀", "✨", "🧘", "〰️", "💫", "🌀", "✨"],
      trajectory: "zen-feathers"
    },

    // === FLUR (8 OBJEKTE) (v0.67) ===
    "FLU_001_01": {
      motionClass: "stage-anim-flu-woodboard",
      auraColor: "rgba(245, 158, 11, 0.65)",
      bannerText: "✨ Kommoden-Holzbrett frei & blitzblank!",
      particles: ["✨", "🪵", "🫧", "🌟", "🧹", "✨", "🫧", "🌟"],
      trajectory: "clean-sweep-sparkles"
    },
    "FLU_002_01": {
      motionClass: "stage-anim-flu-boardgames",
      auraColor: "rgba(236, 72, 153, 0.62)",
      bannerText: "🎲 Witzebuch & Spiele-Archiv: Herzhaft gelacht!",
      particles: ["🎲", "😂", "🃏", "🤣", "✨", "🎭", "🎲", "😂"],
      trajectory: "arcade-combo"
    },
    "FLU_003_01": {
      motionClass: "stage-anim-flu-owlclock",
      auraColor: "rgba(249, 115, 22, 0.68)",
      bannerText: "🦉 5-Uhr-Eule jubelt: 10.000 Schritte im Kasten!",
      particles: ["🦉", "⏰", "👟", "🌅", "🔥", "✨", "🦉", "👟"],
      trajectory: "radial-synth-waves"
    },
    "FLU_004_01": {
      motionClass: "stage-anim-flu-drawers",
      auraColor: "rgba(16, 185, 129, 0.62)",
      bannerText: "🗄️ Textil-Tetris gemeistert: Alles sauber im Fach!",
      particles: ["🗄️", "👕", "🧦", "✨", "✅", "🧺", "👕", "✨"],
      trajectory: "float-up-notes"
    },
    "FLU_005_01": {
      motionClass: "stage-anim-flu-pinboard",
      auraColor: "rgba(234, 88, 12, 0.62)",
      bannerText: "📌 Familien-Pinnwand: Kindergarten-Start geglückt!",
      particles: ["📌", "🎒", "👧", "💛", "✅", "✨", "📌", "🎒"],
      trajectory: "warm-hearts"
    },
    "FLU_006_01": {
      motionClass: "stage-anim-flu-keybowl",
      auraColor: "rgba(56, 189, 248, 0.64)",
      bannerText: "🕶️ Schlüssel, Brille & Sonne: Ab nach draußen!",
      particles: ["🕶️", "🔑", "☀️", "🌳", "👣", "✨", "🕶️", "☀️"],
      trajectory: "zen-feathers"
    },
    "FLU_007_01": {
      motionClass: "stage-anim-flu-coatstand",
      auraColor: "rgba(34, 197, 94, 0.62)",
      bannerText: "🧥 Garderoben-Quest: Sicher wieder zuhause!",
      particles: ["🧥", "🛍️", "🏡", "💛", "✨", "🎉", "🧥", "💛"],
      trajectory: "warm-hearts"
    },
    "FLU_008_01": {
      motionClass: "stage-anim-flu-empore-build",
      auraColor: "rgba(250, 204, 21, 0.72)",
      bannerText: "🧰 Großprojekt Empore & Flurebene (+1000 XP / +1000 G)!",
      particles: ["🧰", "🪚", "🔩", "📏", "🪵", "🏆", "🪙", "🔥"],
      trajectory: "arcade-combo"
    },

    // === BADEZIMMER (7 OBJEKTE) (v0.68) ===
    "BAD_MB_001": {
      motionClass: "stage-anim-bad-swimbag",
      auraColor: "rgba(14, 165, 233, 0.68)",
      bannerText: "🏊 Bahn frei! +5 MB Wasser-Frische-Boost!",
      particles: ["🏊", "🌊", "🥽", "💦", "🐬", "✨", "🌊", "💦"],
      trajectory: "radial-synth-waves"
    },
    "BAD_MB_002": {
      motionClass: "stage-anim-bad-coldshower",
      auraColor: "rgba(56, 189, 248, 0.72)",
      bannerText: "🚿 Frostblitz-Dusche: 100 % hellwach & fokussiert!",
      particles: ["🚿", "❄️", "💧", "⚡", "🧊", "✨", "❄️", "💧"],
      trajectory: "arcade-combo"
    },
    "BAD_MB_003": {
      motionClass: "stage-anim-bad-venla",
      auraColor: "rgba(45, 212, 191, 0.65)",
      bannerText: "💊 Tägliche Routine sitzt: Neuro-Buff aktiv (+50 XP)!",
      particles: ["💊", "🧠", "⚡", "✨", "💚", "💧", "🧠", "✨"],
      trajectory: "float-up-notes"
    },
    "BAD_MB_004": {
      motionClass: "stage-anim-bad-mirror",
      auraColor: "rgba(250, 204, 21, 0.62)",
      bannerText: "🪞 Kurzer Blick in den Spiegel: Sei stolz & milde mit dir!",
      particles: ["🪞", "💛", "✨", "🌿", "😌", "🌟", "💛", "✨"],
      trajectory: "warm-hearts"
    },
    "BAD_AUF_001": {
      motionClass: "stage-anim-bad-washmachine",
      auraColor: "rgba(59, 130, 246, 0.65)",
      bannerText: "🧺 Schleudergang läuft: Wäscheberg bezwungen!",
      particles: ["🧺", "🫧", "🌀", "👕", "✨", "💧", "🫧", "🌀"],
      trajectory: "radial-synth-waves"
    },
    "BAD_AUF_002": {
      motionClass: "stage-anim-bad-cleaner",
      auraColor: "rgba(34, 197, 94, 0.65)",
      bannerText: "✨ Bad-Samstagsputz: Armaturen glänzen wie Zwergengold!",
      particles: ["✨", "🧽", "🫧", "💎", "🌟", "💧", "✨", "🫧"],
      trajectory: "clean-sweep-sparkles"
    },
    "BAD_AUF_003": {
      motionClass: "stage-anim-bad-towels",
      auraColor: "rgba(251, 191, 36, 0.62)",
      bannerText: "🧖 Frisch aus dem Trockner: Flauschig gestapelt!",
      particles: ["🧖", "♨️", "✨", "🧺", "☁️", "💛", "♨️", "✨"],
      trajectory: "rising-steam"
    },

    // === SCHLAFZIMMER (8 OBJEKTE) (v0.69) ===
    "SCH_MB_001": {
      motionClass: "stage-anim-sch-massage",
      auraColor: "rgba(244, 114, 182, 0.62)",
      bannerText: "💆 Wellness-Oase: Schultern entspannt & +2 MB getankt!",
      particles: ["💆", "🌸", "✨", "🕯️", "🌿", "💛", "🌸", "✨"],
      trajectory: "zen-feathers"
    },
    "SCH_MB_002": {
      motionClass: "stage-anim-sch-pillows",
      auraColor: "rgba(251, 146, 60, 0.65)",
      bannerText: "🕯️ Geborgenheit & Nähe: Sicherer Hafen zu zweit!",
      particles: ["🧡", "💛", "✨", "🫂", "🌙", "💫", "🧡", "✨"],
      trajectory: "warm-hearts"
    },
    "SCH_MB_003": {
      motionClass: "stage-anim-sch-telescope",
      auraColor: "rgba(99, 102, 241, 0.68)",
      bannerText: "🔭 Sternklare Nacht: Weitblick & innere Ruhe (+2 MB)!",
      particles: ["🔭", "🌙", "⭐", "🌌", "✨", "☄️", "🌟", "🌙"],
      trajectory: "radial-synth-waves"
    },
    "SCH_MB_004": {
      motionClass: "stage-anim-sch-yogamat",
      auraColor: "rgba(34, 197, 94, 0.65)",
      bannerText: "🧘 Sport-Quest & Planking: Körper-Akku aufgeladen!",
      particles: ["🧘", "💪", "🔥", "⚡", "✨", "🏆", "💪", "🔥"],
      trajectory: "arcade-combo"
    },
    "SCH_MB_005": {
      motionClass: "stage-anim-sch-runningshoes",
      auraColor: "rgba(14, 165, 233, 0.65)",
      bannerText: "👟 10.000 Schritte im Kasten: Starke Ausdauer (+50 XP)!",
      particles: ["👟", "👣", "💨", "🌳", "🏅", "✨", "👟", "👣"],
      trajectory: "float-up-notes"
    },
    "SCH_MB_006": {
      motionClass: "stage-anim-sch-journal",
      auraColor: "rgba(250, 204, 21, 0.66)",
      bannerText: "📓 Eigene Stärken schwarz auf weiß: Selbstwert-Schild aktiv!",
      particles: ["📓", "✍️", "🌟", "🦁", "💡", "✨", "💛", "🌟"],
      trajectory: "warm-hearts"
    },
    "SCH_MB_007": {
      motionClass: "stage-anim-sch-candles",
      auraColor: "rgba(239, 68, 68, 0.64)",
      bannerText: "🕯️ Warmes Kerzenlicht & Zweisamkeit: Koop-Quest perfekt!",
      particles: ["🕯️", "❤️", "🔥", "✨", "💖", "🌙", "❤️", "✨"],
      trajectory: "warm-hearts"
    },
    "SCH_AUF_001": {
      motionClass: "stage-anim-sch-cleanbed",
      auraColor: "rgba(45, 212, 191, 0.65)",
      bannerText: "🛏️ Schlafzimmer-Samstagsputz: Frische Bettwäsche (+150 XP)!",
      particles: ["🛏️", "✨", "🫧", "🌬️", "🌟", "🪶", "✨", "🫧"],
      trajectory: "clean-sweep-sparkles"
    },

    // === DYNAMISCHE PUTZ-SPRITES AN DER TÜR (STUFEN 1–3) ===
    "CLEAN_STAGE_1": {
      motionClass: "stage-anim-vacuum-sweep",
      auraColor: "rgba(22, 163, 74, 0.65)",
      bannerText: "🧹 Frühstart-Besen (x2.0): Raum sofort blitzblank!",
      particles: ["🧹", "✨", "🌟", "💨", "🫧", "✨", "🏆", "🌟"],
      trajectory: "clean-sweep-sparkles"
    },
    "CLEAN_STAGE_2": {
      motionClass: "stage-anim-vacuum-sweep",
      auraColor: "rgba(234, 88, 12, 0.62)",
      bannerText: "🧹 Kehrset-Einsatz (x1.7): Alles weggefegt!",
      particles: ["🧹", "✨", "🫧", "💨", "🌟", "✨", "🫧", "🌟"],
      trajectory: "clean-sweep-sparkles"
    },
    "CLEAN_STAGE_3": {
      motionClass: "stage-anim-vacuum-sweep",
      auraColor: "rgba(220, 38, 38, 0.62)",
      bannerText: "🔌 Staubsauger-Power (x1.4): Chaos besiegt!",
      particles: ["🔌", "💨", "✨", "🫧", "🌟", "⚡", "✨", "🌟"],
      trajectory: "clean-sweep-sparkles"
    }
  };

  function getObjectStageAnimation(obj) {
    if (!obj) return null;
    if (obj.isDirtCleaner) {
      return OBJECT_STAGE_ANIMATIONS[`CLEAN_STAGE_${obj.dirtLevel || 1}`] || OBJECT_STAGE_ANIMATIONS["CLEAN_STAGE_1"];
    }
    if (OBJECT_STAGE_ANIMATIONS[obj.id]) {
      return OBJECT_STAGE_ANIMATIONS[obj.id];
    }
    // Fallback für Räume, die als Nächstes folgen
    return {
      motionClass: "stage-anim-generic-celebrate",
      auraColor: "rgba(255, 146, 43, 0.55)",
      bannerText: `✨ ${obj.name} erledigt!`,
      particles: ["✨", "⭐", "🪙", "🎉", "✨", "⭐", "💫", "🎉"],
      trajectory: "float-up-notes"
    };
  }

  function getLucasArtsQuip(obj) {
    if (!obj) return "";
    if (obj.isDirtCleaner) {
      return LUCASARTS_QUIPS[`CLEAN_STAGE_${obj.dirtLevel || 1}`] || LUCASARTS_QUIPS["CLEAN_STAGE_1"];
    }
    if (LUCASARTS_QUIPS[obj.id]) {
      return LUCASARTS_QUIPS[obj.id];
    }
    return `„Sieht aus wie ${obj.repr || obj.name}. Wenn ich das jetzt erledige, winken +${obj.xp || 0} XP!“`;
  }

  // --- TAGESZEITEN-LICHTWECHSEL ENGINE (v0.54) ---
  // Morgenlicht: 05:00–08:59 | Tageslicht: 09:00–16:59 | Golden Hour: 17:00–20:59 | Nachtlicht: 21:00–04:59
  const TIME_PHASES = {
    morning: {
      id: "morning",
      icon: "🌅",
      label: "Morgenlicht (5–9 Uhr)",
      shortLabel: "Morgen",
      hoursText: "05:00 – 09:00 Uhr",
      desc: "Kühles, frisches Morgenlicht mit sanftem Rosa-Blau-Schimmer"
    },
    day: {
      id: "day",
      icon: "☀️",
      label: "Tageslicht (9–17 Uhr)",
      shortLabel: "Tag",
      hoursText: "09:00 – 17:00 Uhr",
      desc: "Klares, unverfälschtes Tageslicht in voller Farbbrillanz"
    },
    golden: {
      id: "golden",
      icon: "🌇",
      label: "Golden Hour (17–21 Uhr)",
      shortLabel: "Abend",
      hoursText: "17:00 – 21:00 Uhr",
      desc: "Warme, gold-orange Abendsonne mit leichtem Lampenschimmer"
    },
    night: {
      id: "night",
      icon: "🌙",
      label: "Nachtlicht (21–5 Uhr)",
      shortLabel: "Nacht",
      hoursText: "21:00 – 05:00 Uhr",
      desc: "Gemütliches Nachtblau mit warm leuchtenden Lampen & flackernden Kerzen"
    },
    off: {
      id: "off",
      icon: "⚪",
      label: "Lichtfilter Aus",
      shortLabel: "Aus",
      hoursText: "Deaktiviert",
      desc: "Ohne tageszeitlichen Lichtfilter"
    }
  };

  function getActiveTimePhase() {
    const mode = (state && state.settings && state.settings.timeOfDayMode) || "auto";
    if (mode !== "auto" && TIME_PHASES[mode]) {
      return Object.assign({ isAuto: false }, TIME_PHASES[mode]);
    }
    const hour = new Date().getHours();
    let phaseKey = "day";
    if (hour >= 5 && hour < 9) {
      phaseKey = "morning";
    } else if (hour >= 9 && hour < 17) {
      phaseKey = "day";
    } else if (hour >= 17 && hour < 21) {
      phaseKey = "golden";
    } else {
      phaseKey = "night";
    }
    return Object.assign({ isAuto: true, currentHour: hour }, TIME_PHASES[phaseKey]);
  }


  // --- WOCHEN-RÜCKBLICK: "ABENTEURER-BILANZ" (7-TAGE-AUSWERTUNG FÜR XP, GOLD & MB%) ---
  function getWeeklyAdventurerBalance() {
    const weekdays = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
    const logs = (state && state.questlog) || [];
    const snapshots = (state && state.dailyMbSnapshots) || {};
    const currentMb = Number((state && state.character && state.character.mb) ?? 95);

    const days = [];
    const now = new Date();

    // Erzeuge die letzten 7 Kalendertage (von vor 6 Tagen bis Heute)
    for (let offset = 6; offset >= 0; offset--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - offset);
      const datumStr = d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
      const shortDate = d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" });
      const wd = weekdays[d.getDay()];

      let xpGain = 0;
      let goldGain = 0;
      let mbDelta = 0;
      let questsCount = 0;

      logs.forEach(entry => {
        if (entry.datum === datumStr && entry.typ !== "System") {
          const x = Number(entry.xp) || 0;
          const g = Number(entry.gold) || 0;
          const m = Number(entry.mb) || 0;
          if (x > 0) xpGain += x;
          if (g > 0) goldGain += g; // Zählt verdientes Gold (ohne Shop-Ausgaben)
          mbDelta += m;
          if (entry.typ === "Aufgabe" || entry.typ === "Erholung") {
            questsCount += 1;
          }
        }
      });

      days.push({
        datum: datumStr,
        shortDate: shortDate,
        weekday: wd,
        isToday: offset === 0,
        xp: xpGain,
        gold: goldGain,
        mbDelta: mbDelta,
        questsCount: questsCount,
        mbSnapshot: typeof snapshots[datumStr] === "number" ? snapshots[datumStr] : null
      });
    }

    // Rekonstruiere tägliche MB% rückwärts vom heutigen Stand, falls für ältere Tage noch kein Snapshot vorliegt
    let runningMb = currentMb;
    for (let i = days.length - 1; i >= 0; i--) {
      if (days[i].mbSnapshot !== null) {
        days[i].mbPct = Math.max(0, Math.min(100, Math.round(days[i].mbSnapshot)));
        runningMb = days[i].mbPct;
      } else {
        days[i].mbPct = Math.max(0, Math.min(100, Math.round(runningMb)));
      }
      runningMb = Math.max(25, Math.min(100, runningMb - (days[i].mbDelta || 0)));
    }

    const maxXp = Math.max(100, ...days.map(d => d.xp));
    const maxGold = Math.max(50, ...days.map(d => d.gold));

    const totalXp = days.reduce((acc, d) => acc + d.xp, 0);
    const totalGold = days.reduce((acc, d) => acc + d.gold, 0);
    const totalQuests = days.reduce((acc, d) => acc + d.questsCount, 0);
    const avgMb = Math.round(days.reduce((acc, d) => acc + d.mbPct, 0) / days.length);

    let bestDay = days[days.length - 1];
    days.forEach(d => {
      if ((d.xp + d.gold * 2) >= (bestDay.xp + bestDay.gold * 2)) {
        bestDay = d;
      }
    });

    return {
      days,
      maxXp,
      maxGold,
      totalXp,
      totalGold,
      totalQuests,
      avgMb,
      bestDay
    };
  }

  function loadState() {
    const today = new Date().toISOString().split("T")[0];
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const merged = Object.assign({}, defaultState, parsed);
        merged.settings = Object.assign({}, defaultState.settings, merged.settings || {});
        if (!Array.isArray(merged.luggageChestItems)) {
          merged.luggageChestItems = [];
        }
        if (!merged.roomDirtLevels) {
          merged.roomDirtLevels = JSON.parse(JSON.stringify(defaultState.roomDirtLevels));
        }
        delete merged.roomDirtLevels["Dashboard"];
        delete merged.roomDirtLevels["Arbeitszimmer"];
        delete merged.roomDirtLevels["Kinderzimmer"];
        if (merged.lastCompletedDate !== today) {
          merged.completedToday = {};
          merged.lastCompletedDate = today;
          // Jeden neuen Tag werden nur die 5 Wohnräume mit Müll-Logik um +1 Stufe schmutziger (max. Stufe 3)
          ["Flur", "Wohnzimmer", "Küche", "Schlafzimmer", "Badezimmer"].forEach(r => {
            merged.roomDirtLevels[r] = Math.min(3, (merged.roomDirtLevels[r] || 0) + 1);
          });
        }
        return merged;
      }
    } catch (e) {}
    const fresh = JSON.parse(JSON.stringify(defaultState));
    fresh.lastCompletedDate = today;
    return fresh;
  }

  function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function shouldShowDailySplash() {
    const today = new Date().toISOString().split("T")[0];
    const lastShown = localStorage.getItem(SPLASH_DATE_KEY);
    if (lastShown !== today) {
      localStorage.setItem(SPLASH_DATE_KEY, today);
      return true;
    }
    return false;
  }

  function resetDailySplashLock() {
    localStorage.removeItem(SPLASH_DATE_KEY);
  }

  // Spielt entweder die hinterlegte MP3 aus "Frontend_Raum_Objekte" (soundUrl) oder den 16-Bit-Chiptune-Sound ab
  function playObjectSound(soundUrl) {
    playSynthSuccess();
    if (soundUrl) {
      try {
        const cleanUrl = soundUrl.replace("/sfx/", "/sounds/");
        const audio = new Audio(cleanUrl);
        audio.volume = 0.7;
        audio.play().catch(() => {});
      } catch (e) {}
    }
  }

  function playSynthSuccess() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const now = ctx.currentTime;
      [523.25, 659.25, 783.99].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(freq, now + i * 0.08);
        gain.gain.setValueAtTime(0.14, now + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.24);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.24);
      });
    } catch (e) {}
  }

  // --- LIVE GET-REQUEST AN DEIN GOOGLE APPS SCRIPT (doGet v0.3) ---
  async function fetchFromGoogleSheet() {
    if (!GAS_API_URL) return { ok: false };
    try {
      const resp = await fetch(GAS_API_URL, { method: "GET" });
      const json = await resp.json();
      if (json && json.status === "success" && json.data) {
        const d = json.data;
        if (typeof d.mb === "number") state.character.mb = d.mb;
        if (typeof d.hp === "number") state.character.hp = d.hp;
        if (typeof d.level === "number") state.character.level = d.level;
        if (typeof d.xp === "number") state.character.xp = d.xp;
        if (typeof d.gold === "number") state.character.gold = d.gold;
        if (typeof d.ap === "number") state.character.ap = d.ap;
        if (d.levelProgress) state.character.levelProgressText = d.levelProgress;
        if (d.aktuelleQuest) state.character.aktuelleQuest = d.aktuelleQuest;

        // Falls das erweiterte doGet v0.3 auch die Shop-Liste, MB-Aktivitäten & Aufgaben (inkl. Spalte M "Raum" & Spalte N "Repräsentiert durch") mitliefert:
        if (Array.isArray(d.shop) && d.shop.length > 0) {
          SHOP_ITEMS.length = 0;
          d.shop.forEach(sItem => SHOP_ITEMS.push(sItem));
        }
        state.sheetCatalog = {
          mbAktivitaeten: d.mbAktivitaeten || [],
          aufgaben: d.aufgaben || [],
          objects: d.objects || []
        };

        saveState();
        return { ok: true, data: d };
      }
    } catch (err) {
      console.warn("Offline-Modus aktiv (Sheet-GET optional):", err);
    }
    return { ok: false };
  }

  // --- LIVE POST-REQUEST AN DEIN GOOGLE APPS SCRIPT (doPost -> processAction) ---
  function postToGoogleSheet(type, itemName) {
    if (!GAS_API_URL || !state.settings.liveSheetSync) return;
    const payload = {
      action: "processAction",
      type: type,     // Exakt wie in deinem Apps Script erwartet: "MB Aktivitaeten", "Aufgaben" oder "Shop"
      name: itemName  // Exakt der Name in Spalte A deiner Tabelle
    };
    fetch(GAS_API_URL, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload)
    }).catch(() => {});
  }

  // --- VERSTÄRKERLOGIK: MULTIPLIKATOR NACH VERSCHMUTZUNGS-STUFE ---
  // Stufe 1 (Leicht unordentlich / Besen an der Tür) => x2.0 Maximaler Frühstart-Bonus!
  // Stufe 2 (Mittelmäßig unordentlich / Kehrset)     => x1.7 (-0.3)
  // Stufe 3 (Dreckig / Staubsauger)                  => x1.4 (-0.6)
  function getDirtMultiplier(level) {
    const lvl = Number(level) || 0;
    if (lvl <= 0) return 1.0;
    return Math.max(1.0, Math.round((2.0 - (lvl - 1) * 0.3) * 10) / 10);
  }

  // Nur diese 5 echten Wohnräume nutzen die Müll-/Verstärkerlogik (Dashboard & Kinderzimmer sind dauerhaft ausgenommen!)
  const DIRT_ENABLED_ROOMS = ["Flur", "Wohnzimmer", "Küche", "Schlafzimmer", "Badezimmer"];

  function isRoomDirtEnabled(roomName) {
    return DIRT_ENABLED_ROOMS.includes(roomName);
  }

  function getRoomDirtLevel(roomName) {
    if (!isRoomDirtEnabled(roomName)) return 0;
    if (!state.roomDirtLevels) {
      state.roomDirtLevels = JSON.parse(JSON.stringify(defaultState.roomDirtLevels));
    }
    const lvl = state.roomDirtLevels[roomName];
    return typeof lvl === "number" ? Math.min(3, Math.max(0, lvl)) : 0;
  }

  function setRoomDirtLevel(roomName, level) {
    if (!isRoomDirtEnabled(roomName)) return;
    if (!state.roomDirtLevels) {
      state.roomDirtLevels = JSON.parse(JSON.stringify(defaultState.roomDirtLevels));
    }
    state.roomDirtLevels[roomName] = Math.min(3, Math.max(0, Number(level) || 0));
    saveState();
  }

  // --- SPARZIEL-TRACKER FÜR GROSSPROJEKTE IM SHOP (v0.59 - ID- & Namens-synchron mit Google Sheet) ---
  function getPinnedShopGoal() {
    const rawPin = (state && state.settings && state.settings.pinnedShopGoalId) || "Effektpedal kaufen";
    const normPin = String(rawPin).trim().toLowerCase();

    // Legacy-Mapping falls noch SHOP_005 / SHOP_5 o.ä. gespeichert war
    const legacyById = {
      "shop_001": "wow spielen", "shop_1": "wow spielen",
      "shop_002": "xbox spielen", "shop_2": "xbox spielen",
      "shop_003": "steam spielen", "shop_3": "steam spielen",
      "shop_004": "viennese", "shop_4": "viennese",
      "shop_005": "effektpedal kaufen", "shop_5": "effektpedal kaufen",
      "shop_006": "akai mpc sample", "shop_6": "akai mpc sample"
    };
    const targetNameNorm = legacyById[normPin] || normPin;

    const item = SHOP_ITEMS.find(i =>
      String(i.id || "").trim().toLowerCase() === normPin ||
      String(i.name || "").trim().toLowerCase() === targetNameNorm
    ) || SHOP_ITEMS.find(i => Number(i.preisGold) >= 10000) || SHOP_ITEMS[0];

    if (!item) return null;
    const currentGold = Math.max(0, Number(state.character.gold) || 0);
    const targetGold = Math.max(1, Number(item.preisGold) || 1);
    const rawPct = (currentGold / targetGold) * 100;
    const pct = Math.min(100, Math.round(rawPct));
    const exactPct = Math.min(100, Math.round(rawPct * 10) / 10);
    const missingGold = Math.max(0, targetGold - currentGold);
    const canAffordGold = currentGold >= targetGold;
    const canAffordAp = (Number(state.character.ap) || 0) >= (Number(item.kostenAp) || 0);
    return {
      item,
      id: item.id,
      name: item.name,
      currentGold,
      targetGold,
      pct,
      exactPct,
      missingGold,
      canAffordGold,
      canAffordAll: canAffordGold && canAffordAp
    };
  }

  function setPinnedShopGoal(itemIdentifier) {
    if (!state.settings) state.settings = {};
    const found = SHOP_ITEMS.find((it, idx) =>
      String(idx) === String(itemIdentifier) ||
      it.id === itemIdentifier ||
      it.name === itemIdentifier
    );
    // Speichere immer den eindeutigen Item-Namen, damit ein Google-Sheet-Sync (SHOP_1 vs SHOP_001) den Pin niemals überschreibt!
    state.settings.pinnedShopGoalId = found ? found.name : itemIdentifier;
    saveState();
    return getPinnedShopGoal();
  }

  // --- PARALYSE-BRECHER (#1) & POMODORO-ZEIT-PARSER (#3) (v0.58) ---
  function getQuestDurationMinutes(obj) {
    if (!obj) return 5;
    const txt = `${obj.name || ""} ${obj.anzeigeName || ""}`;
    const match = txt.match(/(\d+)\s*(?:min|Min|Minuten)/i);
    if (match && match[1]) {
      return Math.max(1, parseInt(match[1], 10));
    }
    // Falls keine explizite Minutenzahl im Namen steht: Sinnvolle Kurz-Defaults (5 bis 15 Min)
    if (txt.includes("Samstagsputz") || txt.includes("Bauprojekt") || txt.includes("Bewerbung")) return 15;
    if (txt.includes("Vibe Coding") || txt.includes("ADHD Quest programmieren")) return 20;
    if (txt.includes("Atemübung") || txt.includes("Venla")) return 2;
    return 5;
  }

  // --- FLOW-COMBO, LIVE-RADAR, MIKROSCHRITT (25%) & UNDO-SNAPSHOT ENGINE (v0.61) ---
  let lastActionUndoSnapshot = null;
  let flowComboState = { count: 0, lastTimestamp: 0 };

  function getFlowComboInfo() {
    const now = Date.now();
    // Flow-Combo hält 15 Minuten (900.000 ms) zwischen zwei erledigten Aufgaben an
    if (flowComboState.lastTimestamp > 0 && (now - flowComboState.lastTimestamp) <= 15 * 60 * 1000) {
      const mult = Math.min(1.5, Math.round((1.0 + Math.max(0, flowComboState.count - 1) * 0.1) * 10) / 10);
      return { count: flowComboState.count, multiplier: mult, active: flowComboState.count >= 2 };
    }
    return { count: 0, multiplier: 1.0, active: false };
  }

  function getRoomRadarStats(roomName) {
    const objs = (ROOM_OBJECTS[roomName] || []).filter(o => !o.isMapDoor && !o.isShopTrigger && !isObjectInLuggage(o.id));
    const completed = (state && state.completedToday) || {};
    const doneCount = objs.filter(o => !!completed[o.id]).length;
    const totalCount = objs.length;
    const openCount = Math.max(0, totalCount - doneCount);
    const hasDirt = isRoomDirtEnabled(roomName);
    const dirtLvl = hasDirt ? getRoomDirtLevel(roomName) : 0;
    const dirtMult = hasDirt ? getDirtMultiplier(dirtLvl) : 1.0;
    return {
      roomName,
      doneCount,
      totalCount,
      openCount,
      hasDirt,
      dirtLvl,
      dirtMult
    };
  }

  // --- AUFGABE ODER MB-AKTIVITÄT ABSCHLIESSEN (INKL. 2-MIN-MIKROSCHRITT, FLOW-COMBO & UNDO-SNAPSHOT) ---
  function completeObject(obj, options = {}) {
    const isMicroStep = !!options.isMicroStep;
    const microFactor = isMicroStep ? 0.25 : 1.0;

    // 1. Snapshot für "[↩ Rückgängig]" vor der Änderung anlegen
    lastActionUndoSnapshot = {
      character: JSON.parse(JSON.stringify(state.character)),
      roomDirtLevels: JSON.parse(JSON.stringify(state.roomDirtLevels || {})),
      completedToday: JSON.parse(JSON.stringify(state.completedToday || {})),
      dailyMbSnapshots: JSON.parse(JSON.stringify(state.dailyMbSnapshots || {})),
      flowComboState: Object.assign({}, flowComboState),
      objName: obj.name
    };

    // 2. Flow-Combo aktualisieren (innerhalb von 15 Minuten steigt der XP-Multiplikator um +10% pro Aufgabe bis x1.5)
    const nowMs = Date.now();
    if (flowComboState.lastTimestamp > 0 && (nowMs - flowComboState.lastTimestamp) <= 15 * 60 * 1000) {
      flowComboState.count += 1;
    } else {
      flowComboState.count = 1;
    }
    flowComboState.lastTimestamp = nowMs;
    const comboMult = Math.min(1.5, Math.round((1.0 + Math.max(0, flowComboState.count - 1) * 0.1) * 10) / 10);

    const roomName = obj.raum || state.settings.currentRoom || "Flur";
    const dirtLvl = getRoomDirtLevel(roomName);
    const isCleaningQuest = !!(obj.isDirtCleaner || (obj.name && (obj.name.includes("Samstagsputz") || obj.name.includes("aufräumen") || obj.name.includes("Tisch abwischen"))));
    const dirtMult = (isCleaningQuest && dirtLvl >= 1 && !isMicroStep) ? getDirtMultiplier(dirtLvl) : 1.0;

    const rawXp = (Number(obj.xp) || 0) * dirtMult * comboMult * microFactor;
    const rawGold = (Number(obj.gold) || 0) * dirtMult * microFactor;
    const rawMb = (Number(obj.mb) || 0) * microFactor;
    const rawAp = (Number(obj.ap) || 0) * microFactor;

    const xpGain = (Number(obj.xp) || 0) > 0 ? Math.max(1, Math.round(rawXp)) : 0;
    const goldGain = (Number(obj.gold) || 0) > 0 ? Math.max(1, Math.round(rawGold)) : 0;
    const mbGain = rawMb > 0 ? Math.max(1, Math.round(rawMb)) : Math.round(rawMb);
    const apGain = (Number(obj.ap) || 0) > 0 ? (isMicroStep ? Math.max(0, Math.round(rawAp)) : Math.round(rawAp)) : 0;

    if (isCleaningQuest && dirtLvl >= 1 && !isMicroStep) {
      state.roomDirtLevels[roomName] = 0; // Raum ist nach dem vollen Putzen wieder blitzblank (Stufe 0)!
    }

    state.character.xp += xpGain;
    state.character.gold = Math.max(0, state.character.gold + goldGain);
    state.character.mb = Math.min(100, Math.max(0, state.character.mb + mbGain));
    state.character.ap = Math.max(0, state.character.ap + apGain);
    if (!isMicroStep) {
      state.completedToday[obj.id] = true;
    }

    const now = new Date();
    const datumStr = now.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
    const zeitStr = now.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

    const logTitle = isMicroStep ? `👣 2-Min-Start: ${obj.name}` : obj.name;

    // Exakt nach Struktur deines Tabellenblatts "Questlog" (Spalten A bis H)
    state.questlog.unshift({
      datum: datumStr,
      uhrzeit: zeitStr,
      aktivitaet: logTitle,
      typ: obj.zielTabelle === "Aufgaben" ? "Aufgabe" : "Erholung",
      xp: xpGain,
      mb: mbGain,
      gold: goldGain,
      ap: apGain
    });

    if (!state.dailyMbSnapshots) state.dailyMbSnapshots = {};
    state.dailyMbSnapshots[datumStr] = state.character.mb;

    playObjectSound(obj.soundUrl);
    saveState();

    // Synchronisiert automatisch mit deinem Google Sheet via doPost(e)
    if (!isMicroStep && (obj.zielTabelle === "Aufgaben" || obj.zielTabelle === "MB Aktivitaeten")) {
      postToGoogleSheet(obj.zielTabelle, obj.name);
    }

    return {
      xpGain,
      goldGain,
      mbGain,
      apGain,
      dirtMult,
      comboCount: flowComboState.count,
      comboMult,
      isMicroStep
    };
  }

  function canUndoLastAction() {
    return !!lastActionUndoSnapshot;
  }

  function undoLastAction() {
    if (!lastActionUndoSnapshot) return { ok: false };
    const snap = lastActionUndoSnapshot;
    state.character = snap.character;
    state.roomDirtLevels = snap.roomDirtLevels;
    state.completedToday = snap.completedToday;
    state.dailyMbSnapshots = snap.dailyMbSnapshots;
    flowComboState = snap.flowComboState;
    if (state.questlog && state.questlog.length > 0) {
      state.questlog.shift();
    }
    lastActionUndoSnapshot = null;
    saveState();
    return { ok: true, objName: snap.objName };
  }

  // --- SHOP-KAUF (PRÜFT GOLD IN B10 UND AP IN D10 WIE IM APPS SCRIPT) ---
  function buyShopItem(item) {
    const goldCost = Number(item.preisGold) || 0;
    const apCost = Number(item.kostenAp) || 0;

    if (state.character.gold < goldCost || state.character.ap < apCost) {
      return {
        ok: false,
        msg: "⚠️ Zu wenig Ressourcen! Absolviere erst mehr Aufgaben und verdien es Dir!"
      };
    }

    state.character.gold -= goldCost;
    state.character.ap -= apCost;

    const now = new Date();
    const datumStr = now.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
    const zeitStr = now.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

    state.questlog.unshift({
      datum: datumStr,
      uhrzeit: zeitStr,
      aktivitaet: item.name,
      typ: "Shop",
      xp: 0,
      mb: 0,
      gold: -goldCost,
      ap: -apCost
    });

    playSynthSuccess();
    saveState();
    postToGoogleSheet("Shop", item.name);

    return {
      ok: true,
      msg: `🎉 Gekauft: ${item.name} (-${goldCost} Gold, -${apCost} AP)`
    };
  }

  function exportBackup() {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `ADHD_Quest_SheetBackup_v${APP_VERSION}.json`;
    a.click();
  }

  return {
    APP_VERSION,
    GAS_API_URL,
    ASSETS,
    PLAYER_DESIGN_REF,
    ROOMS,
    ROOM_OBJECTS,
    SHOP_ITEMS,
    ACHIEVEMENTS,
    DEFAULT_SHEET_CATALOG,
    getRoomCatalog,
    getTop3FrequentActivities,
    isRoomDirtEnabled,
    getDirtMultiplier,
    getRoomDirtLevel,
    setRoomDirtLevel,
    updateObjectLayout,
    resetObjectLayout,
    resetRoomLayout,
    exportRoomLayoutCode,
    getLuggageChestItems,
    isObjectInLuggage,
    findObjectByIdAcrossRooms,
    getLuggageChestObjectsDetailed,
    storeObjectInLuggage,
    restoreObjectFromLuggage,
    emptyLuggageChest,
    TIME_PHASES,
    getActiveTimePhase,
    getWeeklyAdventurerBalance,
    LUCASARTS_QUIPS,
    getLucasArtsQuip,
    OBJECT_STAGE_ANIMATIONS,
    getObjectStageAnimation,
    getPinnedShopGoal,
    setPinnedShopGoal,
    getQuestDurationMinutes,
    getFlowComboInfo,
    getRoomRadarStats,
    canUndoLastAction,
    undoLastAction,
    getState: () => state,
    saveState,
    shouldShowDailySplash,
    resetDailySplashLock,
    fetchFromGoogleSheet,
    completeObject,
    buyShopItem,
    exportBackup
  };
})();
